<?php


$contract_id      = ! empty( $_GET['contract_id'] ) ?  $_GET['contract_id']  : '';
$site_url         = ! empty( $_GET['domain'] ) ?  $_GET['domain']  : '';
$plan_id          = ! empty( $_GET['plan_id'] ) ?  $_GET['plan_id']  : '';
$billing_period   = ! empty( $_GET['billing_period'] ) ?  $_GET['billing_period']  : '';


$mysqli = mysqli_init();      

$mysqli->ssl_set(NULL, NULL, $_ENV['PLANETSCALE_SSL_CERT_PATH'], NULL, NULL);
$mysqli->real_connect($_ENV['PLANETSCALE_DB_HOST'], $_ENV['PLANETSCALE_DB_USERNAME'], $_ENV['PLANETSCALE_DB_PASSWORD'], $_ENV['PLANETSCALE_DB']);   


//check if the user_id already exists in the table. If it does, update the row.
$row_updated = false;
// $user_data_row = getUserDataByUserId($user_id);

$db = $_ENV['PLANETSCALE_DB'];

//add a new row
$date = date('Y-m-d H:i:s');
$is_blacklist = 0;
$sql = "INSERT INTO `$db` .`oauth_login` (`website_domain`, `woo_contract_id`, `woo_plan_type`, `is_blacklist`, `date_created` ) VALUES ('$site_url', '$contract_id', '$plan_id', $is_blacklist, '$date' );";

$result = $mysqli->query($sql);
$mysqli->close();

if ( ! empty( $contract_id ) ) {
	$channel       = ! empty( $_GET['channel'] ) ? sanitize_text_field( $_GET['channel'] ) : '';
	$redirect_url  = $site_url . '/wp-admin/admin.php?page=ced_amazon&status=1&contract_id=' . $contract_id;
	header( 'Location: ' . $redirect_url );

} else {
	$redirect_url = $site_url . '/wp-admin/admin.php?page=ced_amazon&status=0&contract_id=';
	header( 'Location: ' . $redirect_url );
}


?>