<?php
if ( ! isset( $_SERVER['HTTP_REFERER'] ) ) {
	//die( 'denied' );
}

if(isset($_GET['code'])) {

	$redirect_uri = base64_decode( $_GET['state'] ) ."&state=" . $_GET['state'] . "&code=" . $_GET['code'];
	header( 'location:' . $redirect_uri );
	exit;

} elseif(isset($_GET['state'])) {

	$redirect_uri = base64_decode( $_GET['state'] );
	header( 'location:' . $redirect_uri );
	exit;

}else {
	return;
}
