<?php

// ini_set('display_errors', 1);
// ini_set('display_startup_errors', 1);
// error_reporting(E_ALL);

$body       = isset( $_POST['body'] ) ? json_decode( $_POST['body'], true ) : array();
// print_r($body);
$action     = isset( $body['action'] ) ? $body['action'] : '';
$shop_name  = isset( $body['shop_name'] ) ? $body['shop_name'] : '';
$shop_id    = isset( $body['shop_id'] ) ? $body['shop_id'] : '';
$query_args = isset( $body['query_args'] ) ? $body['query_args'] : array();
$parameters = isset( $body['parameters'] ) ? $body['parameters'] : array();
$status = 400;
$message = '';
if( 'get_notice' == $action ) {
	$message = "<h3>Alert : <i>Etsy Integration for WooCommerce</i></h3><p>We wanted to acknowledge you that we have now released the update for the plugin <b>[ version 2.1.8 ]</b> which is build on Etsy's latest V3 api . You can update the new version <b>[ version 2.1.8 ]</b> to avoid any difficulties with your selling process . In order to update the plugin download the latest package from your <b><a href='https://woocommerce.com/my-account/downloads/' target='_blank'><i>WooCommerce</i></a></b> account or contact <b><a href='mailto:support@cedcommerce.com'><i>CedCommerce</i></a></b> . Ignore incase your plugin is upto date .</p><p>Incase of any difficulties please contact through <u><i><b>live chat</b></i></u> option at the bottom.</p>";
	echo json_encode(
		array(
			'status'  => 300,
			'message' => $message,
		)
	);
	die;
}
if ( ! isset( $body['user_details']['token'] ) ) {

	$legacy_token = isset( $body['user_details']['access_token']['oauth_token'] ) ? $body['user_details']['access_token']['oauth_token'] : '';
	$params   = array(
		'grant_type'   => 'token_exchange',
		'client_id'    => 'ghvcvauxf2taqidkdx2sw4g4',
		'legacy_token' => $legacy_token,
	);
	$response     = get_token( $shop_name, $body, $params );
	$token        = json_decode( $response, true );
	$access_token = isset( $token['access_token'] ) ? $token['access_token'] : '';

} else {

	$refresh_token = isset( $body['user_details']['token']['refresh_token'] ) ? $body['user_details']['token']['refresh_token'] : '';
	$params    = array(
		'grant_type'    => 'refresh_token',
		'client_id'     => 'ghvcvauxf2taqidkdx2sw4g4',
		'refresh_token' => $refresh_token,
	);

	$response     = get_token( $shop_name, $body, $params );
	$token        = json_decode( $response, true );
	$access_token = isset( $token['access_token'] ) ? $token['access_token'] : '';
	
}
switch ( $action ) {

	case 'get_shipping_profiles':
	$result = get( "application/shops/{$shop_id}/shipping-profiles", $shop_name, $query_args, $access_token );
	$status = 200;
	break;
	case 'update_listing':
	$listing_id = $parameters['listing_id'];
	$result = post( "application/shops/{$shop_id}/listings/{$listing_id}", $parameters, $shop_name, $query_args, 'PUT', $access_token );
	$status = 200;
	break;

	default:
	$result  = array();
	$status  = 400;
	$message = 'Invalid endpoint';
	break;

}

echo json_encode(
	array(
		'status'  => $status,
		'message' => $message,
		'result'  => $result,
		'token'   => $token,
	)
);
die;

function get( $action = '', $shop_name = '', $query_args = array(), $access_token = '' ) {

	$base_url  = 'https://api.etsy.com/v3/';
	$api_url   = $base_url . $action;
	$client_id = 'ghvcvauxf2taqidkdx2sw4g4';
	if ( ! empty( $query_args ) ) {
		$api_url = $api_url . '?' . http_build_query( $query_args );
	}

	$header = array(
		'Content-Type: application/json',
		'Accept: application/json',
		'x-api-key: ' . $client_id,
	);

	if ( ! empty( $access_token ) ) {
		$header[] = 'Authorization: Bearer ' . $access_token;
	}

	$curl = curl_init();
	curl_setopt_array(
		$curl,
		array(
			CURLOPT_URL            => $api_url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST  => 'GET',
			CURLOPT_HTTPHEADER     => $header,
		)
	);

	$response = curl_exec( $curl );
	curl_close( $curl );
	return $response;

}

function post( $action = '', $parameters = array(), $shop_name = '', $query_args = array(), $request_type = 'POST', $access_token = '' ) {

	$base_url  = 'https://api.etsy.com/v3/';
	$client_id = 'ghvcvauxf2taqidkdx2sw4g4';
	$api_url   = $base_url . $action;
	if ( ! empty( $query_args ) ) {
		$api_url = $api_url . '?' . http_build_query( $query_args );
	}

	$header = array(
		'Content-Type: application/json',
		'Accept: application/json',
		'x-api-key: ' . $client_id,
	);

	if ( ! empty( $access_token ) && $action != 'public/oauth/token' ) {
		$header[] = 'Authorization: Bearer ' . $access_token;
	}

	$curl = curl_init();
	curl_setopt_array(
		$curl,
		array(
			CURLOPT_URL            => $api_url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST  => $request_type,
			CURLOPT_POSTFIELDS     => json_encode( $parameters ),
			CURLOPT_HTTPHEADER     => $header,
		)
	);

	$response = curl_exec( $curl );
	curl_close( $curl );
	return $response;

}


function get_token( $shop_name, $body, $parameters = array() ) {

	$curl      = curl_init();
	$client_id = 'ghvcvauxf2taqidkdx2sw4g4';
	curl_setopt_array(
		$curl,
		array(
			CURLOPT_URL            => 'https://api.etsy.com/v3/public/oauth/token?' . http_build_query( $parameters ),
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST  => 'POST',
			CURLOPT_POSTFIELDS     => json_encode( $parameters ),
			CURLOPT_HTTPHEADER     => array(
				'Content-Type: application/json',
				'x-api-key: ' . $client_id,
			),
		)
	);

	$response = curl_exec( $curl );
	$error = curl_error( $curl );
	curl_close( $curl );
	return $response;

}
