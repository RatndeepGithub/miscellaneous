<?php
$state     = isset( $_GET['state'] ) ? $_GET['state'] : null;
$code      = isset( $_GET['code'] ) ? $_GET['code'] : '';
$Tempstate = explode( '.', $state );


if ( isset( $Tempstate ) && ! empty( $Tempstate ) && is_array( $Tempstate ) ) {
	$check_remote = json_decode( base64_decode( $Tempstate[1] ), 1 );
   if( $_SERVER['REMOTE_ADDR'] == "103.97.184.122" ) {
//echo'<pre>';       
 //print_r( $Tempstate );
      //   var_dump( $check_remote );
    //     print_r(base64_decode(base64_encode(base64_decode( $Tempstate[1] ))));
   //      die("l");
     }
    if( isset($check_remote['is_remote']) && true == $check_remote['is_remote'] ) {
        $CedredirectUri  = base64_decode($check_remote['redirect_uri']);
        $CedredirectUri .= '&code=' . $code . '&state=' . $state;
        echo "<script> window.location = '" . $CedredirectUri . "'</script>";
        exit;
    }
    if ( isset( $Tempstate[2] ) ) {
      $CedredirectUri  = 'https://apiconnect.sellernext.com/apiconnect/request/commenceAuth';
      $CedredirectUri .= '?code=' . $code . '&state=' . $state;
      echo "<script> window.location = '" . $CedredirectUri . "'</script>";
      exit;
  }
}

if ( ! empty( $state ) ) {
	$redirectUri  = base64_decode( $state );
	$redirectUri .= '&code=' . $code;
	echo "<script> window.location = '" . $redirectUri . "'</script>";
} else {
	echo '{"status": false}';
}


