<?php
/**
 * The base configuration for WordPress
 *
 * The wp-config.php creation script uses this file during the installation.
 * You don't have to use the web site, you can copy this file to "wp-config.php"
 * and fill in the values.
 *
 * This file contains the following configurations:
 *
 * * Database settings
 * * Secret keys
 * * Database table prefix
 * * ABSPATH
 *
 * @link https://wordpress.org/support/article/editing-wp-config-php/
 *
 * @package WordPress
 */

// ** Database settings - You can get this info from your web host ** //
/** The name of the database for WordPress */
define( 'DB_NAME', 'lazada-connector' );

/** Database username */
define( 'DB_USER', 'phpmyadmin' );

/** Database password */
define( 'DB_PASSWORD', '09ylMqe14b2' );

/** Database hostname */
define( 'DB_HOST', 'localhost' );

/** Database charset to use in creating database tables. */
define( 'DB_CHARSET', 'utf8mb4' );

/** The database collate type. Don't change this if in doubt. */
define( 'DB_COLLATE', '' );
define( 'FS_METHOD', 'direct' );

/**#@+
 * Authentication unique keys and salts.
 *
 * Change these to different unique phrases! You can generate these using
 * the {@link https://api.wordpress.org/secret-key/1.1/salt/ WordPress.org secret-key service}.
 *
 * You can change these at any point in time to invalidate all existing cookies.
 * This will force all users to have to log in again.
 *
 * @since 2.6.0
 */
define( 'AUTH_KEY',         'N9)M]/ixG06MZjdwf<`.U`=1>W8ShxxGdKN$Xr,.MhRoS_H%_,I2fOQ,Hv<]&q`%' );
define( 'SECURE_AUTH_KEY',  '<y$cHg0`Rc&A).6(#}RGQ:Q~.?^(<YZXJA? ymtO#O8YK<QkfTp(.w2Aatc}!Db>' );
define( 'LOGGED_IN_KEY',    'DIS8VDLK0NjN)jE$Dw#bo=C}7qU=NJmt@Gc#Pi7$W)mwzur$#/Gxyw+]^MbS#RlT' );
define( 'NONCE_KEY',        'O.lC)B[BN(Vq>O2x-mOP[`D3s_$)Tu]KO0G](Oi.78hOyd>Q>nxn%/D>:>%l;2*X' );
define( 'AUTH_SALT',        '2t;&0T4xD<{I`f%dg,P3NRwM67K1@{Q(dIhb8Q)QhQ>j wG[SM!EJ;>HvOz2gTt5' );
define( 'SECURE_AUTH_SALT', '{%1.!^;e=5m)U+=}J)xP>*]W;H)aMz,hN-Ab.C 5&BsV;,*a W&JF.z*S[G^s0Vj' );
define( 'LOGGED_IN_SALT',   '#T:]knFla(^C2[WMQNhZaZdE<--R#B~&W<k8 x3m@Sl0|#R>!d,Fe:#4VmWp$rq+' );
define( 'NONCE_SALT',       '(],[pF2=_sjf$IBp5|&RDUJR2_Fb:E(3lPnt(ttwxLw(C_EGgLn5aJyZ,#VZZ0I~' );

/**#@-*/

/**
 * WordPress database table prefix.
 *
 * You can have multiple installations in one database if you give each
 * a unique prefix. Only numbers, letters, and underscores please!
 */
$table_prefix = 'wp_';

/**
 * For developers: WordPress debugging mode.
 *
 * Change this to true to enable the display of notices during development.
 * It is strongly recommended that plugin and theme developers use WP_DEBUG
 * in their development environments.
 *
 * For information on other constants that can be used for debugging,
 * visit the documentation.
 *
 * @link https://wordpress.org/support/article/debugging-in-wordpress/
 */
define( 'WP_DEBUG', false );

/* Add any custom values between this line and the "stop editing" line. */



/* That's all, stop editing! Happy publishing. */

/** Absolute path to the WordPress directory. */
if ( ! defined( 'ABSPATH' ) ) {
	define( 'ABSPATH', __DIR__ . '/' );
}

/** Sets up WordPress vars and included files. */
require_once ABSPATH . 'wp-settings.php';
