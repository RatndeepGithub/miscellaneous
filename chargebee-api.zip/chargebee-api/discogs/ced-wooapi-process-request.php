<?php
/**
 * Discogs WooAPI Process Request (Server)
 *
 * @package  ced-discogs-integration
 * @version  1.0.0
 * @link     https://cedcommerce.com
 * @since    1.0.0
 */

$parameters    = ! empty( $_POST ) ? $_POST : '';
$domain_name   = ! empty( $_POST['domain_name'] ) ? $_POST['domain_name'] : '';
$username      = ! empty( $_POST['username'] ) ? $_POST['username'] : '';
$call_type     = ! empty( $_POST['call_type'] ) ? $_POST['call_type'] : '';
$channel       = ! empty( $_POST['channel'] ) ? $_POST['channel'] : '';
$function_type = ! empty( $_POST['function_type'] ) ? $_POST['function_type'] : '';
$is_active     = check_active_subscription( $domain_name, $channel, $username, $call_type );
if ( $is_active ) {
	require_once 'class-ced-discogs-helper-file.php';
	$ced_discogs_product_helper_obj = new Ced_Discogs_Helper_File();
	$response_data                  = $ced_discogs_product_helper_obj->$function_type( $parameters );
	echo $response_data;
} else {
	echo json_encode(
		array(
			'code'    => '400',
			'message' => 'Sorry You are not allowed to use the API requests. Please contact Cedcommerce for more information.',
		)
	);
}

/**
 * Check_active_subscription
 *
 * @param  mixed $domain_name domain_name.
 * @param  mixed $channel channel.
 * @param  mixed $marketplace_userid marketplace_userid.
 * @param  mixed $call_type call_type.
 * @return mixed.
 */
function check_active_subscription( $domain_name = '', $channel = '', $marketplace_userid = '', $call_type = '' ) {
	$servername = 'localhost';
	$username   = 'phpmyadmin';
	$password   = '09ylMqe14b2';
	$dbname     = 'chargbee-api';
	$active     = false;
	$conn       = new mysqli( $servername, $username, $password, $dbname );
	if ( $conn->connect_error ) {
		return false;
	} else {
		$sql  = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain_name' AND `userid` = '$marketplace_userid' AND `channel`='$channel' AND `status`='active'";
		$data = $conn->query( $sql );
		if ( $data->num_rows > 0 ) {
			$active_data = $data->fetch_assoc();
			if ( ! empty( $active_data ) ) {
				$subscription_data = unserialize( $active_data['subscription'] );
				if ( isset( $subscription_data['import'] ) && 'import' === $call_type ) {
					$total  = isset( $subscription_data['import']['total'] ) ? $subscription_data['import']['total'] : 0;
					$remain = isset( $subscription_data['import']['remain'] ) ? $subscription_data['import']['remain'] : 0;
					if ( 'Unlimited' === $remain && 'Unlimited' === $total ) {
						return true;
					} elseif ( $remain > 0 && $remain <= $total ) {
						return true;
					} else {
						return false;
					}
				} elseif ( isset( $subscription_data['export'] ) && 'export' === $call_type ) {
					$total  = isset( $subscription_data['export']['total'] ) ? $subscription_data['export']['total'] : 0;
					$remain = isset( $subscription_data['export']['remain'] ) ? $subscription_data['export']['remain'] : 0;
					if ( 'Unlimited' === $remain && 'Unlimited' === $total ) {
						return true;
					} elseif ( $remain > 0 && $remain <= $total ) {
						return true;
					} else {
						return false;
					}
				} elseif ( isset( $subscription_data['order'] ) && 'order' === $call_type ) {
					$total  = isset( $subscription_data['order']['total'] ) ? $subscription_data['order']['total'] : 0;
					$remain = isset( $subscription_data['order']['remain'] ) ? $subscription_data['order']['remain'] : 0;
					if ( 'Unlimited' === $remain && 'Unlimited' === $total ) {
						return true;
					} elseif ( $remain > 0 && $remain <= $total ) {
						return true;
					} else {
						return false;
					}
				} elseif ( 'show_all_listings' === $call_type || 'show_single_listing' === $call_type || 'get_release_by_releaseid' === $call_type || 'show_all_orders' === $call_type || 'fix_broken_image' === $call_type || 'sync_status_for_zero' === $call_type || 'get_subscription_data' === $call_type || 'ced_start_free_trial' === $call_type ) {
					return true;
				} else {
					$sql = "UPDATE ced_pricing_plan SET `status` ='restricted' WHERE id = " . $active_data['id'];
					if ( $conn->query( $sql ) === true ) {
						return false;
					} else {
						return false;
					}
				}
			} else {
				return false;
			}
		} elseif ( 'ced_start_free_trial' === $call_type ) {
			return true;
		} else {
			return false;
		}
	}
}
