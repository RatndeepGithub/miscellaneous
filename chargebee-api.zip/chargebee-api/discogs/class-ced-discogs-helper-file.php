<?php
/**
 * Discogs Helper File for functions (Server)
 *
 * @package  ced-discogs-integration
 * @version  1.0.0
 * @link     https://cedcommerce.com
 * @since    1.0.0
 */

if ( ! class_exists( 'Ced_Discogs_Helper_File' ) ) {
	/**
	 * Ced_Discogs_Helper_File
	 */
	class Ced_Discogs_Helper_File {
		/**
		 * Ced_get_listing_by_listingid
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_get_listing_by_listingid( $params = array() ) {
			$username     = ! empty( $params['username'] ) ? $params['username'] : '';
			$listing_id   = ! empty( $params['listing_id'] ) ? $params['listing_id'] : 0;
			$access_token = ! empty( $params['access_token'] ) ? $params['access_token'] : '';
			$action       = 'https://api.discogs.com/marketplace/listings/' . $listing_id . '?token=' . $access_token;
			$file         = 'class-ced-discogs-send-http-request.php';
			if ( file_exists( $file ) ) {
				require_once $file;
				$ced_send_http_request_obj = new Ced_Discogs_Send_HTTP_Request();
				$response                  = $ced_send_http_request_obj->ced_get_http_request( $action );
			}
			return $response;
		}
		/**
		 * Ced_get_release_by_releaseid
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_get_release_by_releaseid( $params = array() ) {
			$release_id   = ! empty( $params['release_id'] ) ? $params['release_id'] : 0;
			$access_token = ! empty( $params['access_token'] ) ? $params['access_token'] : '';
			$action       = 'https://api.discogs.com/releases/' . $release_id . '?token=' . $access_token;
			$file         = 'class-ced-discogs-send-http-request.php';
			if ( file_exists( $file ) ) {
				require_once $file;
				$ced_send_http_request_obj = new Ced_Discogs_Send_HTTP_Request();
				$response                  = $ced_send_http_request_obj->ced_get_http_request( $action );
			}
			return $response;
		}

		/**
		 * Ced_get_all_orders
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_get_all_listings( $params = array() ) {
			$username     = ! empty( $params['username'] ) ? $params['username'] : '';
			$access_token = ! empty( $params['access_token'] ) ? $params['access_token'] : '';
			$pageno       = ! empty( $params['pageno'] ) ? $params['pageno'] : 0;
			$limit        = ! empty( $params['limit'] ) ? $params['limit'] : 0;
			$for_sale     = 'for%20sale';
			$action       = 'https://api.discogs.com/users/' . $username . '/inventory?status=' . $for_sale . '&per_page=' . $limit . '&sort_order=desc&token=' . $access_token . '&page=' . $pageno;
			$file         = 'class-ced-discogs-send-http-request.php';
			if ( file_exists( $file ) ) {
				require_once $file;
				$ced_send_http_request_obj = new Ced_Discogs_Send_HTTP_Request();
				$response                  = $ced_send_http_request_obj->ced_get_http_request( $action );
			}
			return $response;
		}

		/**
		 * Ced_upload_product_data_discogs
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_upload_product_data_discogs( $params = array() ) {
			$username     = ! empty( $params['username'] ) ? $params['username'] : '';
			$access_token = ! empty( $params['access_token'] ) ? $params['access_token'] : '';
			$data         = ! empty( $params['data'] ) ? $params['data'] : '';
			$action       = 'https://api.discogs.com/marketplace/listings?token=' . $access_token;
			$file         = 'class-ced-discogs-send-http-request.php';
			if ( file_exists( $file ) ) {
				require_once $file;
				$ced_send_http_request_obj = new Ced_Discogs_Send_HTTP_Request();
				$response                  = $ced_send_http_request_obj->ced_post_http_request( $action, $data );
			}
			return $response;
		}

		/**
		 * Ced_data_update_discogs
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_data_update_discogs( $params = array() ) {
			$username     = ! empty( $params['username'] ) ? $params['username'] : '';
			$access_token = ! empty( $params['access_token'] ) ? $params['access_token'] : '';
			$listing_id   = ! empty( $params['listing_id'] ) ? $params['listing_id'] : '';
			$data         = ! empty( $params['data'] ) ? $params['data'] : '';
			$action       = 'https://api.discogs.com/marketplace/listings/' . $listing_id . '?token=' . $access_token;
			$file         = 'class-ced-discogs-send-http-request.php';
			if ( file_exists( $file ) ) {
				require_once $file;
				$ced_send_http_request_obj = new Ced_Discogs_Send_HTTP_Request();
				$response                  = $ced_send_http_request_obj->ced_post_http_request( $action, $data );
			}
			return $response;
		}

		/**
		 * Ced_get_all_orders
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_get_all_orders( $params = array() ) {
			$username     = ! empty( $params['username'] ) ? $params['username'] : '';
			$access_token = ! empty( $params['access_token'] ) ? $params['access_token'] : '';
			$pageno       = ! empty( $params['pageno'] ) ? $params['pageno'] : 0;
			$limit        = ! empty( $params['limit'] ) ? $params['limit'] : 0;
			$action       = 'https://api.discogs.com/marketplace/orders?status=All&sort_order=desc&token=' . $access_token . '&per_page=' . $limit . '&page=' . $pageno;
			$file         = 'class-ced-discogs-send-http-request.php';
			if ( file_exists( $file ) ) {
				require_once $file;
				$ced_send_http_request_obj = new Ced_Discogs_Send_HTTP_Request();
				$response                  = $ced_send_http_request_obj->ced_get_http_request( $action );
			}
			return $response;
		}

		/**
		 * Ced_get_order_by_id
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_get_order_by_id( $params = array() ) {
			$username     = ! empty( $params['username'] ) ? $params['username'] : '';
			$access_token = ! empty( $params['access_token'] ) ? $params['access_token'] : '';
			$order_id     = ! empty( $params['order_id'] ) ? $params['order_id'] : '';
			$action       = 'https://api.discogs.com/marketplace/orders/' . $order_id . '?token=' . $access_token;
			$file         = 'class-ced-discogs-send-http-request.php';
			if ( file_exists( $file ) ) {
				require_once $file;
				$ced_send_http_request_obj = new Ced_Discogs_Send_HTTP_Request();
				$response                  = $ced_send_http_request_obj->ced_get_http_request( $action );
			}
			return $response;
		}

		/**
		 * Ced_update_server_subscription_data
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_update_server_subscription_data( $params = array() ) {
			$domain_name        = ! empty( $_POST['domain_name'] ) ? $_POST['domain_name'] : '';
			$marketplace_userid = ! empty( $_POST['username'] ) ? $_POST['username'] : '';
			$call_type          = ! empty( $_POST['call_type'] ) ? $_POST['call_type'] : '';
			$channel            = ! empty( $_POST['channel'] ) ? $_POST['channel'] : '';
			$servername         = 'localhost';
			$username           = 'phpmyadmin';
			$password           = '09ylMqe14b2';
			$dbname             = 'chargbee-api';
			$conn               = new mysqli( $servername, $username, $password, $dbname );
			if ( $conn->connect_error ) {
				echo json_encode(
					array(
						'code'    => '400',
						'message' => 'Server Connection Error. Please Contact Cedcommerce for more Information',
					)
				);
			} else {
				$sql  = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain_name' AND `userid` = '$marketplace_userid' AND `channel`='$channel' AND `status`='active'";
				$data = $conn->query( $sql );
				if ( $data->num_rows > 0 ) {
					$active_data = $data->fetch_assoc();
					if ( ! empty( $active_data ) ) {
						if ( ! empty( $call_type ) ) {
							$subscription_data = unserialize( $active_data['subscription'] );
							$remain            = isset( $subscription_data[ $call_type ]['remain'] ) ? $subscription_data[ $call_type ]['remain'] : '';
							if ( 'Unlimited' === $remain ) {
								$remain = 'Unlimited';
							} else {
								--$remain;
							}
							$subscription_data[ $call_type ]['remain'] = $remain;
							$subscription_data                         = serialize( $subscription_data );
							$sql                                       = "UPDATE ced_pricing_plan SET subscription ='$subscription_data' WHERE id = " . $active_data['id'];
							if ( $conn->query( $sql ) === true ) {
								echo json_encode( array( 'code' => '200' ) );
							} else {
								echo json_encode( array( 'code' => '400' ) );
							}
						} else {
							$sql = "UPDATE ced_pricing_plan SET `status` ='restricted' WHERE id = " . $active_data['id'];
							if ( $conn->query( $sql ) === true ) {
								echo json_encode( array( 'code' => '400' ) );
							}
						}
					}
				}
			}
		}
		/**
		 * Ced_get_subscription_data
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_get_subscription_data( $params = array() ) {
			$domain_name        = ! empty( $_POST['domain_name'] ) ? $_POST['domain_name'] : '';
			$marketplace_userid = ! empty( $_POST['username'] ) ? $_POST['username'] : '';
			$channel            = ! empty( $_POST['channel'] ) ? $_POST['channel'] : '';
			$servername         = 'localhost';
			$username           = 'phpmyadmin';
			$password           = '09ylMqe14b2';
			$dbname             = 'chargbee-api';
			$conn               = new mysqli( $servername, $username, $password, $dbname );
			if ( $conn->connect_error ) {
				echo json_encode(
					array(
						'code'    => '400',
						'message' => 'Server Connection Error. Please Contact Cedcommerce for more Information',
					)
				);
			} else {
				$sql  = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain_name' AND `userid` = '$marketplace_userid' AND `channel`='$channel'";
				$data = $conn->query( $sql );
				if ( $data->num_rows > 0 ) {
					$active_data = $data->fetch_assoc();
					if ( ! empty( $active_data ) ) {
						echo json_encode( $active_data );
					} else {
						echo json_encode(
							array(
								'code'    => '400',
								'message' => 'Your Subscription not Found. Please Contact Cedcommerce for more Information',
							)
						);
					}
				} else {
					echo json_encode(
						array(
							'code'    => '400',
							'message' => 'Your Subscription not Found. Please Contact Cedcommerce for more Information',
						)
					);
				}
			}
		}
		/**
		 * Ced_start_free_trial
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_start_free_trial( $params = array() ) {
			$domain_name        = ! empty( $_POST['domain_name'] ) ? $_POST['domain_name'] : '';
			$marketplace_userid = ! empty( $_POST['username'] ) ? $_POST['username'] : '';
			$channel            = ! empty( $_POST['channel'] ) ? $_POST['channel'] : '';
			$servername         = 'localhost';
			$username           = 'phpmyadmin';
			$password           = '09ylMqe14b2';
			$dbname             = 'chargbee-api';
			$conn               = new mysqli( $servername, $username, $password, $dbname );
			if ( $conn->connect_error ) {
				echo json_encode(
					array(
						'code'    => '400',
						'message' => 'Server Connection Error. Please Contact Cedcommerce for more Information',
					)
				);
			} else {
				$sql  = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain_name' AND `userid` = '$marketplace_userid' AND `channel`='$channel'";
				$data = $conn->query( $sql );
				if ( $data->num_rows > 0 ) {
					$active_data = $data->fetch_assoc();
					echo json_encode(
						array(
							'code'    => '400',
							'message' => 'You have already subscribed so you cannot take the Free Trial.',
						)
					);
				} else {

					$subscription_id = 'ced_trial';
					$subs_data = array(
						'subscription_id' => $subscription_id,
						'subs_plan'       => 'TRIAL',
						'next_billing_at' => '',
						'import'          => array( 'total' => 100, 'remain' => 100 ),
						'export'          => array( 'total' => 100, 'remain' => 100 ),
						'order'           => array( 'total' => 10, 'remain' => 10 ),
					);
					$subs_data_serialize = serialize( $subs_data );
					$sql = "INSERT INTO ced_pricing_plan "."(domain, userid, channel, subscription_id, status, subscription ) " . "VALUES " . "('$domain_name','$marketplace_userid','$channel','$subscription_id', 'active', '$subs_data_serialize')";
					if ( $conn->query( $sql ) ) {
						echo json_encode(
							array(
								'code'    => '200',
								'message' => 'Successfully Started the Trial Version',
							)
						);
					} else {
						echo json_encode(
							array(
								'code'    => '400',
								'message' => $conn->error,
							)
						);
					}
				}
			}
		}

	}
}





