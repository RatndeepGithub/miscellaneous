<?php
/**
 * Discogs Https Request/ Response functions (Server)
 *
 * @package  ced-discogs-integration
 * @version  1.0.0
 * @link     https://cedcommerce.com
 * @since    1.0.0
 */

/**
 * Ced_Discogs_Send_HTTP_Request
 */
class Ced_Discogs_Send_HTTP_Request {

	/**
	 * Ced_get_http_request
	 *
	 * @param  mixed $action action.
	 * @return mixed
	 */
	public function ced_get_http_request( $action = '' ) {
		$curl  = curl_init();
		$agent = 'Mozilla/5.0 (Windows NT 6.2; WOW64; rv:17.0) Gecko/20100101 Firefox/17.0';
		curl_setopt_array(
			$curl,
			array(
				CURLOPT_URL            => $action,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING       => '',
				CURLOPT_MAXREDIRS      => 10,
				CURLOPT_TIMEOUT        => 30,
				CURLOPT_USERAGENT      => $agent,
				CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST  => 'GET',
				CURLOPT_HTTPHEADER     => array(
					'Content-Type: application/json',
				),
			)
		);
		$response = curl_exec( $curl );
		return $response;
	}
	/**
	 * Ced_post_http_request
	 *
	 * @param  mixed $action action.
	 * @param  mixed $post_data post_data.
	 * @return mixed
	 */
	public function ced_post_http_request( $action = '', $post_data = '' ) {

		$curl  = curl_init();
		$agent = 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)';
		curl_setopt_array(
			$curl,
			array(
				CURLOPT_URL            => $action,
				CURLOPT_RETURNTRANSFER => true,
				CURLOPT_ENCODING       => '',
				CURLOPT_MAXREDIRS      => 10,
				CURLOPT_TIMEOUT        => 30,
				CURLOPT_USERAGENT      => $agent,
				CURLOPT_POSTFIELDS     => $post_data,
				CURLOPT_HTTP_VERSION   => CURL_HTTP_VERSION_1_1,
				CURLOPT_CUSTOMREQUEST  => 'POST',
				CURLOPT_HTTPHEADER     => array(
					'Content-Type: application/json',
				),
			)
		);
		$response = curl_exec( $curl );
		return $response;
	}

}
