<?php
$parameters    = ! empty( $_POST ) ? $_POST : '';
$domain_name   = ! empty( $_POST['domain_name'] ) ? $_POST['domain_name'] : '';
$username      = ! empty( $_POST['username'] ) ? $_POST['username'] : '';
$call_type     = ! empty( $_POST['call_type'] ) ? $_POST['call_type'] : '';
$channel       = ! empty( $_POST['channel'] ) ? $_POST['channel'] : '';
$function_type = ! empty( $_POST['function_type'] ) ? $_POST['function_type'] : '';
$is_active     = check_active_subscription( $domain_name, $channel, $username, $call_type );
if($is_active)
{

	$fileName        			= require_once 'class-ced-bigcommerce-ProductHelper.php';
	$ced_b2w_productHelperObj 	= new Ced_Bigcommerce_Product_Helper();
	$response_data	= $ced_b2w_productHelperObj->$function_type($parameters);
	echo ($response_data);
}
else	
{
	echo json_encode(array('status'=> 400,'message' => 'Sorry You are not allowed to use the API requests. Please contact CedCommerce for more information.'));
}
function check_active_subscription( $domain_name = '', $channel = '', $marketplace_userid = '', $call_type = '' ) {
	$servername = 'localhost';
	$username   = 'phpmyadmin';
	$password   = 'cedcom2020$';
	$dbname     = 'chargbee-api';
	$active     = false;
	$conn       = new mysqli( $servername, $username, $password, $dbname );
	if ( $conn->connect_error ) {
		return false;
	} else {
		$sql  = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain_name' AND `userid` = '$marketplace_userid' AND `channel`='$channel' AND `status`='active'";
		$data = $conn->query( $sql );
		if ( $data->num_rows > 0 ) {
			$active_data = $data->fetch_assoc();
			if ( ! empty( $active_data ) ) {
				$subscription_data = unserialize( $active_data['subscription'] );
				if ( isset( $subscription_data['import_product'] ) && 'import_product' === $call_type ) {
					$total  = isset( $subscription_data['import_product']['total'] ) ? $subscription_data['import_product']['total'] : 0;
					$remain = isset( $subscription_data['import_product']['remain'] ) ? $subscription_data['import_product']['remain'] : 0;
					if ( $remain > 0 && $remain <= $total ) {
						return true;
					} else {
						return false;
					}
				} elseif ( isset( $subscription_data['import_customer'] ) && 'import_customer' === $call_type ) {
					$total  = isset( $subscription_data['import_customer']['total'] ) ? $subscription_data['import_customer']['total'] : 0;
					$remain = isset( $subscription_data['import_customer']['remain'] ) ? $subscription_data['import_customer']['remain'] : 0;
					if ( $remain > 0 && $remain <= $total ) {
						return true;
					} else {
						return false;
					}
				} elseif ( isset( $subscription_data['import_order'] ) && 'import_order' === $call_type ) {
					$total  = isset( $subscription_data['import_order']['total'] ) ? $subscription_data['import_order']['total'] : 0;
					$remain = isset( $subscription_data['import_order']['remain'] ) ? $subscription_data['import_order']['remain'] : 0;
					if ( $remain > 0 && $remain <= $total ) {
						return true;
					} else {
						return false;
					}
				} elseif ( 'fetch_collections' === $call_type || 'fetch_smart_collections' === $call_type || 'get_all_collection_product' === $call_type || 'get_total_customers' === $call_type || 'get_total_orders' === $call_type || 'sync_status_for_zero' === $call_type || 'get_subscription_data' === $call_type ) {
					return true;
				} else {
					$sql = "UPDATE ced_pricing_plan SET `status` ='restricted' WHERE id = " . $active_data['id'];
					if ( $conn->query( $sql ) === true ) {
						return false;
					} else {
						return false;
					}
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
}