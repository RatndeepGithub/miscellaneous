<?php
if ( ! class_exists( 'Ced_Bigcommerce_Product_Helper' ) ) {
	class Ced_Bigcommerce_Product_Helper {

		private static $_instance;
		/**
		 * Get_instance Instance.
		 *
		 * Ensures only one instance of Ced_Bigcommerce_Product_Helper is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @return get_instance instance.
		 */
		public static function get_instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		public function ced_bigcommerce_get_all_products_data( $parms ) {
			$next = !empty( $parms['next'] ) ? $parms['next'] : 0 ; 
			$api_path = !empty( $parms['api_path'] ) ? $parms['api_path'] : ''; 
			$access_token = !empty( $parms['access_token'] ) ? $parms['access_token'] : ''; 
			$product_chunk_size = !empty( $parms['product_chunk_size'] ) ? $parms['product_chunk_size'] : ''; 
			
		
			if( !empty( $product_chunk_size ) ){
				$chunk = $product_chunk_size;
			}else{
				$chunk = 5;
			}
			if( '' == $next ){
				$next = "?limit=".$chunk."&page=1";
			}
			
			$action = "v3/catalog/products" . $next;
			$file_name = 'class-ced-bigcommerce-sendHttpRequest.php';
			require_once $file_name;
			$ced_Bigcommerce_sendHttpRequestInstance = new Ced_Bigcommerce_Send_HTTP_Request();
			$response = $ced_Bigcommerce_sendHttpRequestInstance->sendHttpRequest( $action,$api_path,$access_token);
			
			return $response;
		}

		public function ced_bigcommerce_get_variations_for_product( $parms ){

			$product_id = !empty( $parms['next'] ) ? $parms['next'] : 0 ; 
			$api_path = !empty( $parms['api_path'] ) ? $parms['api_path'] : ''; 
			$access_token = !empty( $parms['access_token'] ) ? $parms['access_token'] : ''; 

			$render_settings_data = !empty( $parms['render_settings_data'] ) ? $parms['render_settings_data'] : array(); 
			$action = 'v3/catalog/products/'.$product_id.'/variants?page=1&limit=300';
			$file_name = 'class-ced-bigcommerce-sendHttpRequest.php';
			require_once $file_name;
			$ced_Bigcommerce_sendHttpRequestInstance = new Ced_Bigcommerce_Send_HTTP_Request();
			$response = $ced_Bigcommerce_sendHttpRequestInstance->sendHttpRequest( $action ,$api_path,$access_token);
			
			return $response;	
		}

		public function ced_bigcommerce_get_variation_options( $parms ){
			$product_id = !empty( $parms['next'] ) ? $parms['next'] : 0 ; 
			$api_path = !empty( $parms['api_path'] ) ? $parms['api_path'] : ''; 
			$access_token = !empty( $parms['access_token'] ) ? $parms['access_token'] : ''; 
			$render_settings_data = !empty( $parms['render_settings_data'] ) ? $parms['render_settings_data'] : array(); 
			$action = 'v3/catalog/products/'.$product_id.'/options';
			$file_name = 'class-ced-bigcommerce-sendHttpRequest.php';
			require_once $file_name;
			$ced_Bigcommerce_sendHttpRequestInstance = new Ced_Bigcommerce_Send_HTTP_Request();
			$response = $ced_Bigcommerce_sendHttpRequestInstance->sendHttpRequest( $action ,$api_path,$access_token);
			return $response;	
		}

		public function ced_bigcommerce_get_product_images( $parms ){
			$api_path = !empty( $parms['api_path'] ) ? $parms['api_path'] : ''; 
			$access_token = !empty( $parms['access_token'] ) ? $parms['access_token'] : ''; 
			$product_id = !empty( $parms['next'] ) ? $parms['next'] : 0 ; 
			$action = 'v3/catalog/products/'.$product_id.'/images';
			$file_name = 'class-ced-bigcommerce-sendHttpRequest.php';
			require_once $file_name;
			$ced_Bigcommerce_sendHttpRequestInstance = new Ced_Bigcommerce_Send_HTTP_Request();
			$response = $ced_Bigcommerce_sendHttpRequestInstance->sendHttpRequest( $action ,$api_path,$access_token);
			return $response;	
		}

		

		public function ced_bigcommerce_get_all_customers_data( $parms ) {
			
			$next = !empty( $parms['next'] ) ? $parms['next'] : 0 ; 
			$api_path = !empty( $parms['api_path'] ) ? $parms['api_path'] : ''; 
			$access_token = !empty( $parms['access_token'] ) ? $parms['access_token'] : ''; 
			$product_chunk_size = !empty( $parms['product_chunk_size'] ) ? $parms['product_chunk_size'] : ''; 
			// echo '<pre>';
			// print_r($access_token);
			// die('sfr');
			if( !empty( $product_chunk_size ) ){
				$chunk = $product_chunk_size;
			}else{
				$chunk = 5;
			}
			if( '' == $next ){
				$next = "?limit=$chunk&page=1";
			}
			
			$action = "v3/customers" . $next;
			$file_name = 'class-ced-bigcommerce-sendHttpRequest.php';
			require_once $file_name;
			$ced_Bigcommerce_sendHttpRequestInstance = new Ced_Bigcommerce_Send_HTTP_Request();
			$response = $ced_Bigcommerce_sendHttpRequestInstance->sendHttpRequest( $action ,$api_path,$access_token);
			return $response;
		}

		public function ced_bigcommerce_validate_token( $parms ){

			$api_path = !empty( $parms['api_path'] ) ? $parms['api_path'] : '' ; 
			$access_token = !empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$render_settings_data = !empty( $parms['render_settings_data'] ) ? $parms['render_settings_data'] : array(); 
			$file_name = 'class-ced-bigcommerce-sendHttpRequest.php';
			require_once $file_name;
			$ced_Bigcommerce_sendHttpRequestInstance = new Ced_Bigcommerce_Send_HTTP_Request();
			$response = $ced_Bigcommerce_sendHttpRequestInstance->validate_token( $api_path, $access_token );
			// echo '<pre>';
			// var_dump($response);
			// die('gg');
			
			if( isset( $response['data'] ) ){
				return 'valid';
			}
			else if ( isset( $response['status'] ) && '401' == $response['status'] ){
				return 'invalid';
			}
			else {
				return 'invalidpath';
			}
		}


		public function ced_bigcommerce_get_orders($parms){
			$api_path = !empty( $parms['api_path'] ) ? $parms['api_path'] : '' ; 
			$access_token = !empty( $parms['access_tokan'] ) ? $parms['access_tokan'] : '' ; 
			$action = !empty( $parms['action'] ) ? $parms['action'] : '' ; 


			$file_name = 'class-ced-bigcommerce-sendHttpRequest.php';
			require_once $file_name;
			$ced_Bigcommerce_sendHttpRequestInstance = new Ced_Bigcommerce_Send_HTTP_Request();
			$response = $ced_Bigcommerce_sendHttpRequestInstance->sendHttpRequest( $action,$api_path,$access_token);
			
			return $response;
		}





		public function check_product_remaining_calls($parms){
			return 'valid';
		}



		        /**
		 * Ced_update_server_subscription_data
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_update_server_subscription_data( $params = array() ) {
			$domain_name        = ! empty( $_POST['domain_name'] ) ? $_POST['domain_name'] : '';
			$marketplace_userid = ! empty( $_POST['username'] ) ? $_POST['username'] : '';
			$call_type          = ! empty( $_POST['call_type'] ) ? $_POST['call_type'] : '';
			$channel            = ! empty( $_POST['channel'] ) ? $_POST['channel'] : '';
			$servername = 'localhost';
			$username   = 'phpmyadmin';
			$password   = 'cedcom2020$';
			$dbname     = 'chargbee-api';
			$conn               = new mysqli( $servername, $username, $password, $dbname );
			if ( $conn->connect_error ) {
				echo json_encode(
					array(
						'code'    => '400',
						'message' => 'Server Connection Error. Please Contact Cedcommerce for more Information',
					)
				);
			} else {
				$sql  = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain_name' AND `userid` = '$marketplace_userid' AND `channel`='$channel' AND `status`='active'";
				$data = $conn->query( $sql );
				if ( $data->num_rows > 0 ) {
					$active_data = $data->fetch_assoc();
					if ( ! empty( $active_data ) ) {
						if ( ! empty( $call_type ) ) {
							$subscription_data = unserialize( $active_data['subscription'] );
							$remain            = isset( $subscription_data[ $call_type ]['remain'] ) ? $subscription_data[ $call_type ]['remain'] : 0;
							--$remain;
							$subscription_data[ $call_type ]['remain'] = $remain;
							$subscription_data                         = serialize( $subscription_data );
							$sql                                       = "UPDATE ced_pricing_plan SET subscription ='$subscription_data' WHERE id = " . $active_data['id'];
							if ( $conn->query( $sql ) === true ) {
								echo json_encode( array( 'code' => '200' ) );
							} else {
								echo json_encode( array( 'code' => '400' ) );
							}
						} else {
							$sql = "UPDATE ced_pricing_plan SET `status` ='restricted' WHERE id = " . $active_data['id'];
							if ( $conn->query( $sql ) === true ) {
								echo json_encode( array( 'code' => '400' ) );
							}
						}
					}
				}
			}
		}


	}
}
