<?php
class Ced_Bigcommerce_Send_HTTP_Request {

	public $appkey;
	public $password;
	public $api_path;

	public function __construct() {

		//$this->loadDepenedency();
		//$this->api_path                      = $this->ced_api_path;  //'https://api.bigcommerce.com/stores/tcxzwy96a7/'; //$this->ced_swc_configInstance->api_path;
		//$this->ced_bigcommerce_access_token  = $this->ced_api_token;  //'cebjq6rhb7rw7njn0f67ubj70rwrq2s';   //$this->ced_swc_configInstance->ced_bigcommerce_access_token;
	}

	public function validate_token( $api_path = '', $access_token = '' ) {

		if ( '' == $api_path && '' == $access_token  ) {
			return false;
		}
		$chunk = 1;			
		$next = "?limit=$chunk&page=1";
		$action = "v3/catalog/products" . $next;
		
		// initialise a CURL session
		$connection = curl_init();
		$url        = $api_path .'/'. $action;
		$headers    = $this->build_headers( $access_token );
		//var_dump($url);
		curl_setopt( $connection, CURLOPT_URL, $url );
		// stop CURL from verifying the peer's certificate
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		// set the headers using the array of headers
		curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );

		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt($connection, CURLOPT_FAILONERROR, true); 
		$response = curl_exec( $connection );
		// echo '<pre>';
		// print_r($response);
		if (curl_errno($connection)) {
			$error_msg = curl_error($connection);
		}
		// echo '<pre>';
		// var_dump($error_msg);
		curl_close( $connection );
		return $this->parse_response( $response );
	}

	public function sendHttpRequest( $action = '', $api_path,$access_token ) {

		if ( '' == $action ) {
			return false;
		}
		// echo '<pre>';
		// var_dump($api_path);
		// var_dump($access_token);
		// die('gg3344');
		// $api_path=$render_settings_data['api_path'];
		// $access_token=$render_settings_data['access_token'];
		// initialise a CURL session
		$connection = curl_init();
		$url        = $api_path .'/'. $action;
		
		// print_r($this->ced_bigcommerce_access_token);
		$headers    = $this->build_headers( $access_token );

		curl_setopt( $connection, CURLOPT_URL, $url );
		// stop CURL from verifying the peer's certificate
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		// set the headers using the array of headers
		curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );

		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, 1 );

		$response = curl_exec( $connection );
		curl_close( $connection );
		return $response;
		//return $this->parse_response( $response );
	}

	public function PostHttpRequest( $action = '', $encode_product_data = array() ) {

		if ( '' == $action ) {
			return false;
		}

		// initialise a CURL session
		$connection = curl_init();
		$url        = 'https://' . $this->api_path . $action;
		$headers    = $this->build_headers( $this->ced_bigcommerce_access_token );

		curl_setopt( $connection, CURLOPT_URL, $url );
		curl_setopt( $connection, CURLOPT_POST, 1 );
		curl_setopt( $connection, CURLOPT_POSTFIELDS, $encode_product_data );
		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $connection, CURLOPT_FOLLOWLOCATION, 1 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );
		$response = curl_exec( $connection );
		curl_close( $connection );
		return $response;
		//return $this->parse_response( $response );
	}

	public function build_headers( $ced_bigcommerce_access_token ) {

		$headers = array(
			'Content-type: application/json',
			'X-Auth-Token: ' . $ced_bigcommerce_access_token . '',
			'Content-Type: application/json',
    		'Accept: application/json',
		);
		return $headers;
	}

	public function parse_response( $response ) {

		$res = json_decode( $response, true );

		return $res;
	}

	/**
	 * Function loadDepenedency
	 *
	 * @name loadDepenedency
	 */
	public function loadDepenedency($render_settings_data) {

		//$render_settings_data = get_option( 'ced_bigcommerce_settings_data', false );

       	if( isset( $render_settings_data['api_path'] ) && isset( $render_settings_data['access_token'] ) ){
			$this->ced_api_path = str_replace( '/v3/', '', $render_settings_data['api_path'] );
			$this->ced_api_token = $render_settings_data['access_token'];	
	   	}else{
			$this->ced_api_path 	= '';
			$this->ced_api_token 	= '';

		}
		// if ( is_file( __DIR__ . '/ced-swc-config.php' ) ) {
		// 	require_once 'ced-swc-config.php';
		// 	$this->ced_swc_configInstance = Ced_SWC_Config::get_instance();
		// }
	}
}
