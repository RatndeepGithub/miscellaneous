<?php
$parameters    = ! empty( $_POST ) ? $_POST : '';
$domain_name   = ! empty( $_POST['domain_name'] ) ? $_POST['domain_name'] : '';
$username      = ! empty( $_POST['userid'] ) ? $_POST['userid'] : '';
$call_type     = ! empty( $_POST['call_type'] ) ? $_POST['call_type'] : '';
$channel       = ! empty( $_POST['channel'] ) ? $_POST['channel'] : '';
$function_type = ! empty( $_POST['function_type'] ) ? $_POST['function_type'] : '';
$is_active     = check_active_subscription( $domain_name, $channel, $username, $call_type );
if($is_active)
{
	// $parameters = array();
	// $parameters['since_id'] = 0;
	// $parameters['shop_url'] = 'shubhamdev.myshopify.com/';
	// $parameters['access_token'] = "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";
	$fileName        			= require_once 'class-ced-magento2-ProductHelper.php';
	$ced_M2W_productHelperObj 	= new Ced_Magento2_Product_Helper();
	$response_data	= $ced_M2W_productHelperObj->$function_type($parameters);
	echo($response_data);
}
else	
{
	echo json_encode(array('status'=> 400,'message' => 'Sorry You are not allowed to use the API requests. Please contact CedCommerce for more information.'));
}
function check_active_subscription($domain_name = '', $channel = '', $marketplace_userid = '', $call_type = '')
{
	$servername = 'localhost';
	$username   = 'phpmyadmin';
	$password   = 'cedcom2020$';
	$dbname     = 'chargbee-api';
	$active     = false;
	$conn       = new mysqli( $servername, $username, $password, $dbname );
	if ( $conn->connect_error ) {
		return false;
	} else {
		$sql  = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain_name' AND `userid` = '$marketplace_userid' AND `channel`='$channel' AND `status`='active'";
		$data = $conn->query( $sql );
		if ( $data->num_rows > 0 ) {
			$active_data = $data->fetch_assoc();
			if ( ! empty( $active_data ) ) {
				$subscription_data = unserialize( $active_data['subscription'] );
				if ( isset( $subscription_data['import_product'] ) && 'import_product' === $call_type ) {
					$total  = isset( $subscription_data['import_product']['total'] ) ? $subscription_data['import_product']['total'] : 0;
					$remain = isset( $subscription_data['import_product']['remain'] ) ? $subscription_data['import_product']['remain'] : 0;
					if ( $remain > 0 && $remain <= $total ) {
						return true;
					} else {
						return false;
					}
				} elseif ( isset( $subscription_data['import_customer'] ) && 'import_customer' === $call_type ) {
					$total  = isset( $subscription_data['import_customer']['total'] ) ? $subscription_data['import_customer']['total'] : 0;
					$remain = isset( $subscription_data['import_customer']['remain'] ) ? $subscription_data['import_customer']['remain'] : 0;
					if ( $remain > 0 && $remain <= $total ) {
						return true;
					} else {
						return false;
					}
				} elseif ( isset( $subscription_data['import_order'] ) && 'import_order' === $call_type ) {
					$total  = isset( $subscription_data['import_order']['total'] ) ? $subscription_data['import_order']['total'] : 0;
					$remain = isset( $subscription_data['import_order']['remain'] ) ? $subscription_data['import_order']['remain'] : 0;
					if ( $remain > 0 && $remain <= $total ) {
						return true;
					} else {
						return false;
					}
				} elseif ( 'ced_magento2_get_variation_attributes' === $call_type || 'ced_magento2_get_stock' === $call_type || 'ced_magento2_get_variations_for_product' === $call_type || 'get_all_products_data' === $call_type || 'ced_magento2_validate_token' === $call_type || 'ced_magento2_generate_token' === $call_type || 'fetch_collections' === $call_type || 'fetch_smart_collections' === $call_type || 'get_all_collection_product' === $call_type || 'get_total_customers' === $call_type || 'get_total_orders' === $call_type || 'sync_status_for_zero' === $call_type || 'get_subscription_data' === $call_type ) {
					return true;
				} else {
					$sql = "UPDATE ced_pricing_plan SET `status` ='restricted' WHERE id = " . $active_data['id'];
					if ( $conn->query( $sql ) === true ) {
						return false;
					} else {
						return false;
					}
				}
			} else {
				return false;
			}
		} else {
			return false;
		}
	}
}