<?php
if ( ! class_exists( 'Ced_Magento2_Product_Helper' ) ) {
	class Ced_Magento2_Product_Helper {

		private static $_instance;
		/**
		 * Get_instance Instance.
		 *
		 * Ensures only one instance of Ced_Magento2_Product_Helper is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @return get_instance instance.
		 */
		public static function get_instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

		public function ced_magento2_get_all_products_data( $parms ) {
			$limit = !empty( $parms['limit'] ) ? $parms['limit'] : 0 ; 
			$page = !empty( $parms['page'] ) ? $parms['page'] : 0 ; 	
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_magento2_access_token=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$action = '/rest/V1/products?searchCriteria[pageSize]='.$limit.'&searchCriteria[currentPage]='.$page;
			// print_r($action);
			$file_name = 'class-ced-magento2-sendHttpRequest.php';
			require_once $file_name;
			$ced_Magento2_sendHttpRequestInstance = new Ced_Magento2_Send_HTTP_Request();
			$response = $ced_Magento2_sendHttpRequestInstance->sendHttpRequest( $action,$store_address,$ced_magento2_access_token);
			// echo '<pre>';
			// print_r($response);
			// die('fggg');
			return $response;
		}

		public function ced_magento2_get_stock( $parms ){

			$sku=!empty( $parms['sku'] ) ? $parms['sku'] : '' ; 
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_magento2_access_token=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			if( empty($sku)){
				return;
			}
			$action = '/rest/V1/stockItems/'.$sku;
			$file_name = 'class-ced-magento2-sendHttpRequest.php';
			require_once $file_name;
			$ced_Magento2_sendHttpRequestInstance = new Ced_Magento2_Send_HTTP_Request();
			$response = $ced_Magento2_sendHttpRequestInstance->sendHttpRequest( $action,$store_address,$ced_magento2_access_token);
			return $response;	
		}

		public function ced_magento2_get_variations_for_product( $parms ){
			$sku=!empty( $parms['sku'] ) ? $parms['sku'] : '' ; 
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_magento2_access_token=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$action 	= '/rest/default/V1/configurable-products/'.$sku.'/children';
			$file_name = 'class-ced-magento2-sendHttpRequest.php';
			require_once $file_name;
			$ced_Magento2_sendHttpRequestInstance = new Ced_Magento2_Send_HTTP_Request();
			$response = $ced_Magento2_sendHttpRequestInstance->sendHttpRequest( $action,$store_address,$ced_magento2_access_token);
			return $response;	
		}

		public function ced_magento2_get_variation_attributes( $parms ){
			$attribute_ids = !empty( $parms['attr_ids'] ) ? $parms['attr_ids'] : '' ; 
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_magento2_access_token=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$action 	= '/rest/V1/products/attributes?search_criteria[filter_groups][0][filters][0][field]=attribute_id&search_criteria[filter_groups][0][filters][0][value]='. $attribute_ids .'&search_criteria[filter_groups][0][filters][0][condition_type]=in';
			$file_name = 'class-ced-magento2-sendHttpRequest.php';
			require_once $file_name;
			$ced_Magento2_sendHttpRequestInstance = new Ced_Magento2_Send_HTTP_Request();
			$response = $ced_Magento2_sendHttpRequestInstance->sendHttpRequest( $action,$store_address,$ced_magento2_access_token);
			return $response;	
		}

		
		
	
	
		public function ced_magento2_get_all_customers_data( $parms ) {
			
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_magento2_access_token=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$chunk=	!empty( $parms['limit'] ) ? $parms['limit'] : 5 ; 
			$next	=	!empty( $parms['page'] ) ? $parms['page'] : '' ; 
			// if( '' != $next ){
			// 	$next = "?limit=".$chunk."&page=".$next;
			// }
			// var_dump($next);
			// die('33');
			$action = '/rest/V1/customers/search?searchCriteria[pageSize]='.(int)$chunk.'&searchCriteria[currentPage]='.(int)$next.'&searchCriteria[sortOrders][0][field]=email&searchCriteria[sortOrders][0][direction]=asc';
			$file_name = 'class-ced-magento2-sendHttpRequest.php';
			require_once $file_name;
			$ced_magento2_sendHttpRequestInstance = new Ced_magento2_Send_HTTP_Request();
			$response = $ced_magento2_sendHttpRequestInstance->sendHttpRequest( $action,$store_address,$ced_magento2_access_token);
			return $response;
		}

		public function ced_magento2_generate_token( $parms ){

			$store_url=!empty( $parms['storeurl'] ) ? $parms['storeurl'] : '' ; 
			$username=!empty( $parms['username'] ) ? $parms['username'] : '' ; 
			$password=!empty( $parms['password'] ) ? $parms['password'] : '' ; 

			$file_name = 'class-ced-magento2-sendHttpRequest.php';
			require_once $file_name;
			$ced_Magento2_sendHttpRequestInstance = new Ced_Magento2_Send_HTTP_Request();
			$response = $ced_Magento2_sendHttpRequestInstance->generate_token( $store_url, $username, $password );
		//    $response= json_decode($response,true);
			//var_dump($response);
            
            return $response;			
		}
		public function ced_magento2_validate_token( $parms ){

			$store_address = !empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$access_token = !empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 

			$file_name = 'class-ced-magento2-sendHttpRequest.php';
			require_once $file_name;
			$ced_Magento2_sendHttpRequestInstance = new Ced_Magento2_Send_HTTP_Request();
			$response = $ced_Magento2_sendHttpRequestInstance->validate_token( $store_address, $access_token );
			// print_r($response);
            if( isset($response['items']) ){
				echo json_encode(
					array(
						'message'   => 'valid', 
					)
				);
               // return 'valid';
            }
			if('page_not_found' == $response){
				echo json_encode(
					array(
						'message'   => 'invalidpath', 
					)
				);
				//return 'invalidpath';
			}
			if(isset($response['message'])){
				echo json_encode(
					array(
						
						'message'   => 'invalid', 
					)
				);
				return 'invalid';
			}
            //return $response;			
		}


		public function ced_megento2_get_orders_api($parms){

			$store_address = !empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_magento2_access_token = !empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$limit = !empty( $parms['limit'] ) ? $parms['limit'] : 5 ; 
			$page = !empty( $parms['page'] ) ? $parms['page'] : 1 ; 
			$action = "/rest/V1/orders?searchCriteria[pageSize]={$limit}&searchCriteria[currentPage]={$page}";
			$file_name = 'class-ced-magento2-sendHttpRequest.php';
			require_once $file_name;
			$ced_Magento2_sendHttpRequestInstance = new Ced_Magento2_Send_HTTP_Request();
			$response = $ced_Magento2_sendHttpRequestInstance->sendHttpRequest( $action,$store_address,$ced_magento2_access_token);
			return $response;
		}





		public function check_product_remaining_calls($parms){
			return 'valid';
		}



		        /**
		 * Ced_update_server_subscription_data
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_update_server_subscription_data( $params = array() ) {
			$domain_name        = ! empty( $_POST['domain_name'] ) ? $_POST['domain_name'] : '';
			$marketplace_userid = ! empty( $_POST['username'] ) ? $_POST['username'] : '';
			$call_type          = ! empty( $_POST['call_type'] ) ? $_POST['call_type'] : '';
			$channel            = ! empty( $_POST['channel'] ) ? $_POST['channel'] : '';
			$servername = 'localhost';
			$username   = 'phpmyadmin';
			$password   = 'cedcom2020$';
			$dbname     = 'chargbee-api';
			$conn               = new mysqli( $servername, $username, $password, $dbname );
			if ( $conn->connect_error ) {
				echo json_encode(
					array(
						'code'    => '400',
						'message' => 'Server Connection Error. Please Contact Cedcommerce for more Information',
					)
				);
			} else {
				$sql  = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain_name' AND `userid` = '$marketplace_userid' AND `channel`='$channel' AND `status`='active'";
				$data = $conn->query( $sql );
				if ( $data->num_rows > 0 ) {
					$active_data = $data->fetch_assoc();
					if ( ! empty( $active_data ) ) {
						if ( ! empty( $call_type ) ) {
							$subscription_data = unserialize( $active_data['subscription'] );
							$remain            = isset( $subscription_data[ $call_type ]['remain'] ) ? $subscription_data[ $call_type ]['remain'] : 0;
							--$remain;
							$subscription_data[ $call_type ]['remain'] = $remain;
							$subscription_data                         = serialize( $subscription_data );
							$sql                                       = "UPDATE ced_pricing_plan SET subscription ='$subscription_data' WHERE id = " . $active_data['id'];
							if ( $conn->query( $sql ) === true ) {
								echo json_encode( array( 'code' => '200' ) );
							} else {
								echo json_encode( array( 'code' => '400' ) );
							}
						} else {
							$sql = "UPDATE ced_pricing_plan SET `status` ='restricted' WHERE id = " . $active_data['id'];
							if ( $conn->query( $sql ) === true ) {
								echo json_encode( array( 'code' => '400' ) );
							}
						}
					}
				}
			}
		}

	}
}
