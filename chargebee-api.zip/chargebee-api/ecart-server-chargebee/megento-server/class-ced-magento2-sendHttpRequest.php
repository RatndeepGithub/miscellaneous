<?php
class Ced_Magento2_Send_HTTP_Request {

	public $appkey;
	public $password;
	public $store_address;

	public function __construct() {

		//$this->loadDepenedency();
		//$this->store_address                 = $this->ced_store_address;  
		//$this->ced_magento2_access_token     = $this->ced_api_token;  
	}

    //Generating Magento2 Token
	public function generate_token( $store_url, $username, $password ) {

		if ( '' == $store_url && '' == $username && '' == $password  ) {
			return false;
		}

        $url = $store_url;
        $token_url = $url."/rest/V1/integration/admin/token";
        $data = array("username" => $username, "password" => $password );
        $data_string = json_encode($data);
		$connection = curl_init();
		// var_dump($token_url);
		// die('dfdf');
        curl_setopt($connection,CURLOPT_URL, $token_url);
        curl_setopt($connection, CURLOPT_CUSTOMREQUEST, "POST");
        curl_setopt($connection, CURLOPT_POSTFIELDS, $data_string);
        curl_setopt($connection, CURLOPT_RETURNTRANSFER, true);
        curl_setopt($connection, CURLOPT_SSL_VERIFYPEER, false);
        curl_setopt($connection, CURLOPT_HTTPHEADER, array('Content-Type: application/json'));
        $token = curl_exec($connection);
        $httpCode = curl_getinfo($connection, CURLINFO_HTTP_CODE);
        if($httpCode == 404) {
           return 'page_not_found';
        }else{
            return $this->parse_response( $token );
        }
        curl_close( $connection );
    }

	//Validating Magento2 Token by a simple call
	public function validate_token( $store_address = '', $access_token = '' ) {

		if ( '' == $store_address && '' == $access_token  ) {
			return false;
		}
		$action = '/rest/V1/orders?searchCriteria[pageSize]=1&searchCriteria[currentPage]=1';
		
		// initialise a CURL session
		$connection = curl_init();
		$url        = $store_address . $action;
		$headers    = $this->build_headers( $access_token );

		curl_setopt( $connection, CURLOPT_URL, $url );
		// stop CURL from verifying the peer's certificate
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		// set the headers using the array of headers
		curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );

		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, 1 );

		$response = curl_exec( $connection );
		$httpCode = curl_getinfo($connection, CURLINFO_HTTP_CODE);
        if($httpCode == 404) {
           return 'page_not_found';
        }else{
            return $this->parse_response( $response );
        }
		curl_close( $connection );
		return $this->parse_response( $response );
	}

	public function sendHttpRequest( $action = '', $store_address='',$ced_magento2_access_token='') {

		if ( '' == $action ) {
			return false;
		}
		// var_dump($action);
		// die('ghgjhg');
		// initialise a CURL session
		$connection = curl_init();
		$url        = $store_address .'/'. $action;
		
		$headers    = $this->build_headers( $ced_magento2_access_token );

		curl_setopt( $connection, CURLOPT_URL, $url );
		// stop CURL from verifying the peer's certificate
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		// set the headers using the array of headers
		curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );

		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, 1 );

		$response = curl_exec( $connection );
		// echo '<pre>';
		// var_dump($url);
		// print_r($response);
		// die('sdfd');
		curl_close( $connection );
		return $response;
		return $this->parse_response( $response );
	}

	public function PostHttpRequest( $action = '', $encode_product_data = array() ) {

		if ( '' == $action ) {
			return false;
		}

		// initialise a CURL session
		$connection = curl_init();
		$url        = 'https://' . $store_address . $action;
		$headers    = $this->build_headers( $ced_magento2_access_token );

		curl_setopt( $connection, CURLOPT_URL, $url );
		curl_setopt( $connection, CURLOPT_POST, 1 );
		curl_setopt( $connection, CURLOPT_POSTFIELDS, $encode_product_data );
		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $connection, CURLOPT_FOLLOWLOCATION, 1 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );
		$response = curl_exec( $connection );
		curl_close( $connection );
		return $response;
		return $this->parse_response( $response );
	}

	public function build_headers( $ced_magento2_access_token ) {

		$headers = array(
			'Content-type: application/json',
			'Authorization: Bearer ' . $ced_magento2_access_token . '',
			'Content-Type: application/json',
    		'Accept: application/json',
		);
		return $headers;
	}

	public function parse_response( $response ) {

		$res = json_decode( $response, true );

		return $res;
	}

	/**
	 * Function loadDepenedency
	 *
	 * @name loadDepenedency
	 */
	public function loadDepenedency() {

		// $render_settings_data = get_option( 'ced_magento2_settings_data', false );
       	// if( isset( $render_settings_data['store_address'] ) && isset( $render_settings_data['access_token'] ) ){
		// 	$this->ced_store_address  	=  $render_settings_data['store_address'];
		// 	$this->ced_api_token 		= $render_settings_data['access_token'];	
	   	// }else{
		// 	$this->ced_store_address 	= '';
		// 	$this->ced_api_token 		= '';

		// }
	
	}
}
