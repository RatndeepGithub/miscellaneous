<?php
if ( ! class_exists( 'Ced_prestashop_Product_Helper' ) ) {
	class Ced_prestashop_Product_Helper {

		private static $_instance;
		/**
		 * Get_instance Instance.
		 *
		 * Ensures only one instance of Ced_prestashop_Product_Helper is loaded or can be loaded.
		 *
		 * @since 1.0.0
		 * @static
		 * @return get_instance instance.
		 */
		public static function get_instance() {
			if ( is_null( self::$_instance ) ) {
				self::$_instance = new self();
			}
			return self::$_instance;
		}

	//******************************************************* PRODUCTS PRESTASHOP************************************* */

		public function ced_prestashop_get_all_products_data( $parms ) {	
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$limit=	!empty( $parms['limit'] ) ? $parms['limit'] : 5 ; 
			$page	=	!empty( $parms['page'] ) ? $parms['page'] : '' ; 
			$action = '/products?limit='.$page.','.$limit.'&display=full';		
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$response = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;
		}

		public function ced_prestashop_get_specific_price( $parms ){
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$product_id=!empty( $parms['product_id'] ) ? $parms['product_id'] : '' ; 
			$action = '/specific_prices/?display=full&filter[id_product]=['.$product_id.']';		
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$response = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;
		}

		public function ced_prestashop_count_total_products($parms){
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$action = '/products';		
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$response = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;
		}

		public function ced_prestashop_get_image( $product_id, $image_id ){
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$product_id=!empty( $parms['product_id'] ) ? $parms['product_id'] : '' ; 
			$image_id=!empty( $parms['image_id'] ) ? $parms['image_id'] : '' ;
		
			$action = '/images/products/'.$product_id.'/'.$image_id;
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$response = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );			
			return $response;
		}

		public function ced_prestashop_get_stock( $sku ){
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$sku=!empty( $parms['sku'] ) ? $parms['sku'] : '' ;
			if( empty($sku)){
				return;
			}
			$action = '/rest/V1/stockItems/'.$sku;
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$response = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;	
		}

		public function ced_prestashop_get_variations_for_product( $parms ){
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$variation_id=!empty( $parms['var_id'] ) ? $parms['var_id'] : '' ;
			$action 	= '/combinations/'.$variation_id;
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$response = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;	
		}

		public function ced_prestashop_get_variation_product_option_values( $parms ){
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$option_value_id=!empty( $parms['option_val_id'] ) ? $parms['option_val_id'] : '' ;

			$action 	= '/product_option_values/'.$option_value_id;
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$response = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;	
		}

		public function ced_prestashop_get_variation_product_options( $parms ){
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$option_id=!empty( $parms['option_id'] ) ? $parms['option_id'] : '' ;
			$action 	= '/product_options/'.$option_id;
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$response = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;	
		}

		

		public function ced_prestashop_validate_token( $parms ){

			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$access_token=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			// echo '<pre>';
			// print_r($parms);
			// die('fgdfg');
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$response = $ced_prestashop_sendHttpRequestInstance->validate_token( $store_address, $access_token );
			// echo '<pre>';
			// print_r($response);
			// die('fdgdfg');
            if( is_array($response) ){	
               return 'valid';
            }
			if('page_not_found' == $response){
				return 'invalidpath';
			}
			if('unauthorized' == $response){
				return 'invalid';
			}		
		}


//**********************************************************CUSTOMERS PRESTASHOP******************************************************************** */

		public function ced_get_state_prestashop_customer( $parms ){
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$state_id		=	!empty( $parms['state_id'] ) ? $parms['state_id'] : '' ; 
            $action = '/states/'.$state_id;
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$response = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
            return $response;
        }

        public function ced_get_country_prestashop_customer( $parms ){
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$country_id		=	!empty( $parms['country_id'] ) ? $parms['country_id'] : '' ; 
            $action = '/countries/'.$country_id;
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$response = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
            return $response;
        }

        public function ced_get_address_prestashop_customer( $parms ){
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$customer_id=	!empty( $parms['customer_id'] ) ? $parms['customer_id'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
            $action = '/addresses/?filter[id_customer]=['.$customer_id.']&display=full';
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$response = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
            return $response;
        }

        public function ced_get_total_count_prestashop_customer($parms) {  
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
            $action = '/customers';
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			$total_customer = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			$total_customer = json_decode($total_customer,true);
            if( isset( $total_customer['customers'] ) && !empty( $total_customer['customers'] ) && count($total_customer['customers']) > 0 ){
                return count( $total_customer['customers']);
            }else{
                return 0;
            }
        }

        public function ced_prestashop_get_all_customers_data( $parms){
			// var_dump($parms);
			// die('fffff');
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$page=	!empty( $parms['page'] ) ? $parms['page'] : 1 ;
			$limit=	!empty( $parms['limit'] ) ? $parms['limit'] : 2 ;
            $action = '/customers?limit='.$page.','.$limit.'&display=full';
			$ced_prestashop_sendHttpRequestInstance = new Ced_PrestaShop_Send_HTTP_Request();
			// var_dump($ced_prestashop_sendHttpRequestInstance);
			// die('fffff444');
			$response = $ced_prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			// var_dump($response);
			// die('gfg');
			return $response;
        }


//****************************************** ORDERS PRESTASHOP**********************************/

		public function ced_prestashop_get_all_products_data_from_server($parms){
			// var_dump($parms);
			// die('gg');
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$page =	!empty( $parms['page'] ) ? $parms['page'] : 1 ;
			$limit = !empty( $parms['limit'] ) ? $parms['limit'] : 5 ;
            $action = '/orders?limit='.$page.','.$limit.'&display=full';		
            $file_name = 'class-ced-prestashop-sendHttpRequest.php';
			require_once $file_name;
			$ced_Prestashop_sendHttpRequestInstance = new Ced_Prestashop_Send_HTTP_Request();
			$response = $ced_Prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			// echo '<pre>';
			// print_r($response);
			// die('ggg');
            return $response;
        }



		public function ced_get_shipping_address_prestashop($parms){
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$id_address_shipping =	!empty( $parms['address_id'] ) ? $parms['address_id'] : '' ;
			$action = '/addresses/'.$id_address_shipping;		
            $file_name = 'class-ced-prestashop-sendHttpRequest.php';
            require_once $file_name;
            $ced_Prestashop_sendHttpRequestInstance = new Ced_Prestashop_Send_HTTP_Request();
            $response = $ced_Prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;
		}

		public function ced_get_billing_address_prestashop($parms){
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$id_address_billing =	!empty( $parms['address_id_billing'] ) ? $parms['address_id_billing'] : '' ;
			$action = '/addresses/'.$id_address_billing;
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
            require_once $file_name;
            $ced_Prestashop_sendHttpRequestInstance = new Ced_Prestashop_Send_HTTP_Request();
            $response = $ced_Prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;	
		}


		public function ced_get_state_prestashop( $parms ){
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$state_id =	!empty( $parms['state_id'] ) ? $parms['state_id'] : '' ;
            $action = '/states/'.$state_id;
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
            require_once $file_name;
            $ced_Prestashop_sendHttpRequestInstance = new Ced_Prestashop_Send_HTTP_Request();
            $response = $ced_Prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;	
        }

        public function ced_get_country_prestashop( $parms ){
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$country_id = !empty( $parms['country_id'] ) ? $parms['country_id'] : '' ;
            $action = '/countries/'.$country_id;
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
            require_once $file_name;
            $ced_Prestashop_sendHttpRequestInstance = new Ced_Prestashop_Send_HTTP_Request();
            $response = $ced_Prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;	
        }

        public function ced_get_customer_prestashop( $parms ){
            $store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$customer_id = !empty( $parms['customer_id'] ) ? $parms['customer_id'] : '' ;
            $action = '/customers/'.$customer_id;
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
            require_once $file_name;
            $ced_Prestashop_sendHttpRequestInstance = new Ced_Prestashop_Send_HTTP_Request();
            $response = $ced_Prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;
        }

      
        public function ced_get_total_count_prestashop_order() {  
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
            $action = '/orders';		
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
            require_once $file_name;
            $ced_Prestashop_sendHttpRequestInstance = new Ced_Prestashop_Send_HTTP_Request();
            $response = $ced_Prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			// echo '<pre>';
			// print_r($response);
			// die('fff33');
			return $response;
        }


        public function ced_get_order_current_state( $current_state ){
			$store_address=	!empty( $parms['store_address'] ) ? $parms['store_address'] : '' ; 
			$ced_prestashop_access_tokan=	!empty( $parms['access_token'] ) ? $parms['access_token'] : '' ; 
			$current_state = !empty( $parms['current_state'] ) ? $parms['current_state'] : '' ;
            $action = '/order_states/'.$current_state;
			$file_name = 'class-ced-prestashop-sendHttpRequest.php';
            require_once $file_name;
            $ced_Prestashop_sendHttpRequestInstance = new Ced_Prestashop_Send_HTTP_Request();
            $response = $ced_Prestashop_sendHttpRequestInstance->sendHttpRequest( $action ,$store_address ,$ced_prestashop_access_tokan );
			return $response;  
		}
		




		public function check_product_remaining_calls($parms){
			return 'valid';
		}



		        /**
		 * Ced_update_server_subscription_data
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_update_server_subscription_data( $params = array() ) {
			$domain_name        = ! empty( $_POST['domain_name'] ) ? $_POST['domain_name'] : '';
			$marketplace_userid = ! empty( $_POST['username'] ) ? $_POST['username'] : '';
			$call_type          = ! empty( $_POST['call_type'] ) ? $_POST['call_type'] : '';
			$channel            = ! empty( $_POST['channel'] ) ? $_POST['channel'] : '';
			$servername = 'localhost';
			$username   = 'phpmyadmin';
			$password   = 'cedcom2020$';
			$dbname     = 'chargbee-api';
			$conn               = new mysqli( $servername, $username, $password, $dbname );
			if ( $conn->connect_error ) {
				echo json_encode(
					array(
						'code'    => '400',
						'message' => 'Server Connection Error. Please Contact Cedcommerce for more Information',
					)
				);
			} else {
				$sql  = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain_name' AND `userid` = '$marketplace_userid' AND `channel`='$channel' AND `status`='active'";
				$data = $conn->query( $sql );
				if ( $data->num_rows > 0 ) {
					$active_data = $data->fetch_assoc();
					if ( ! empty( $active_data ) ) {
						if ( ! empty( $call_type ) ) {
							$subscription_data = unserialize( $active_data['subscription'] );
							$remain            = isset( $subscription_data[ $call_type ]['remain'] ) ? $subscription_data[ $call_type ]['remain'] : 0;
							--$remain;
							$subscription_data[ $call_type ]['remain'] = $remain;
							$subscription_data                         = serialize( $subscription_data );
							$sql                                       = "UPDATE ced_pricing_plan SET subscription ='$subscription_data' WHERE id = " . $active_data['id'];
							if ( $conn->query( $sql ) === true ) {
								echo json_encode( array( 'code' => '200' ) );
							} else {
								echo json_encode( array( 'code' => '400' ) );
							}
						} else {
							$sql = "UPDATE ced_pricing_plan SET `status` ='restricted' WHERE id = " . $active_data['id'];
							if ( $conn->query( $sql ) === true ) {
								echo json_encode( array( 'code' => '400' ) );
							}
						}
					}
				}
			}
		}

	}
}
