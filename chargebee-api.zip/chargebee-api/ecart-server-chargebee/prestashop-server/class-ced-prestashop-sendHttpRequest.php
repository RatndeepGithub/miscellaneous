<?php
class Ced_PrestaShop_Send_HTTP_Request {

	public $appkey;
	public $password;
	public $store_address;

	public function __construct() {

		// $this->loadDepenedency();
		// $this->store_address                 = $this->ced_store_address;  
		// $this->ced_prestashop_access_token   = $this->ced_api_token; 
	}

	public function validate_token( $store_address = '', $access_token = '' ) {

		if ( '' == $store_address && '' == $access_token  ) {
			return false;
		}
		$access_token = base64_encode( $access_token . ':');
		$action = $store_address . '/api';
		// initialise a CURL session
		$connection = curl_init();
		$url        = $action;
		
		$headers    = $this->build_headers( $access_token );
		// var_dump($url );
		// print_r($headers);
		///die('gg');
		curl_setopt( $connection, CURLOPT_URL, $url );
		// stop CURL from verifying the peer's certificate
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		// set the headers using the array of headers
		curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );

		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, 1 );
		curl_setopt($connection, CURLOPT_FAILONERROR, true); 

	
            //$response = json_decode( $response, true );    
            // if (curl_errno($connection)) {
            //     $error_msg = curl_error($connection);
            // }
		$response = curl_exec( $connection );
		// echo '<pre>';
		// print_r($response);
		// die('fddd');
        $httpCode = curl_getinfo($connection, CURLINFO_HTTP_CODE);
		
        if($httpCode == 404) {
           return 'page_not_found';
        }elseif($httpCode == 401){
			return 'unauthorized';
		}
		else{
            return $this->parse_response( $response );
        }
		curl_close( $connection );
		
	}

	public function sendHttpRequest($action ,$store_address ,$ced_prestashop_access_token ) {

		if ( '' == $action ) {
			return false;
		}
		// initialise a CURL session
		$connection = curl_init();
		$url        = $store_address . '/api'. $action;
		$ced_prestashop_access_token = base64_encode( $ced_prestashop_access_token . ':');
		// print_r($url);
		// die('ff');
		// print_r($this->ced_prestashop_access_token);
		$headers    = $this->build_headers( $ced_prestashop_access_token );

		curl_setopt( $connection, CURLOPT_URL, $url );
		// stop CURL from verifying the peer's certificate
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		// set the headers using the array of headers
		curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );

		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, 1 );

		$response = curl_exec( $connection );
		curl_close( $connection );
		// echo '<pre>';
		// print_r($response);
		// die('999999');
		return $response;
		//return $this->parse_response( $response );
	}

	public function sendHttpRequestforImage( $action = '' ) {
	
		if ( '' == $action ) {
			return false;
		}
		// initialise a CURL session
		$connection = curl_init();
		$url        = $this->store_address . '/api'. $action;

		
		$headers = array(
            'Authorization: Basic '. $this->ced_prestashop_access_token,
			'Output-Format: JSON',
		);
		curl_setopt( $connection, CURLOPT_URL, $url );
		// stop CURL from verifying the peer's certificate
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		// set the headers using the array of headers
		curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );

		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, 1 );

		$response = curl_exec( $connection );
		curl_close( $connection );
		return $response;
	}

	public function PostHttpRequest( $action = '', $encode_product_data = array() ) {

		if ( '' == $action ) {
			return false;
		}

		// initialise a CURL session
		$connection = curl_init();
		$url        = 'https://' . $this->store_address . $action;
		$headers    = $this->build_headers( $this->ced_prestashop_access_token );

		curl_setopt( $connection, CURLOPT_URL, $url );
		curl_setopt( $connection, CURLOPT_POST, 1 );
		curl_setopt( $connection, CURLOPT_POSTFIELDS, $encode_product_data );
		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $connection, CURLOPT_FOLLOWLOCATION, 1 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );
		$response = curl_exec( $connection );
		curl_close( $connection );
		return $this->parse_response( $response );
	}

	public function build_headers( $ced_prestashop_access_token ) {

		$headers = array(
            'Authorization: Basic '. $ced_prestashop_access_token,
            'Output-Format: JSON',
		);
		return $headers;
	}

	public function parse_response( $response ) {

		$res = json_decode( $response, true );

		return $res;
	}

	/**
	 * Function loadDepenedency
	 *
	 * @name loadDepenedency
	 */
	public function loadDepenedency() {

		// $render_settings_data = get_option( 'ced_prestashop_settings_data', false );
       	// if( isset( $render_settings_data['store_address'] ) && isset( $render_settings_data['access_token'] ) ){
		// 	$this->ced_store_address    = $render_settings_data['store_address'];
		// 	$this->ced_api_token        = base64_encode( $render_settings_data['access_token'] . ':' );	
	   	// }else{
		// 	$this->ced_store_address 	= '';
		// 	$this->ced_api_token 	    = '';

		// }
	}
}
