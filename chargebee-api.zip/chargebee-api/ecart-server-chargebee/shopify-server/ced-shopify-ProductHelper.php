<?php
if ( ! class_exists( 'Ced_Shopify_Product_Helper' ) ) {
	class Ced_Shopify_Product_Helper {

      /* ****************************** PRODUCT ******************************* */

		//get collection products data according to collection id
		public function get_all_collection_products( $params = array() ) {
            $value          =  !empty( $params['value'] ) ? $params['value'] : 0 ; 
            $product_limit  =  !empty( $params['product_limit'] ) ? $params['product_limit'] : 0 ; 
            $pageno         =  !empty( $params['pageno'] ) ? $params['pageno'] : 0 ; 

			$action = "admin/api/2021-04/collections/{$value}/products.json?limit={$product_limit}&since_id={$pageno}";
			$fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
			$ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
			return $response;
		}

		//count products in selected collection ids
		public function get_count_of_collectionproducts_on_shopify( $params = array() ) {
            $value =  !empty( $params['value'] ) ? $params['value'] : 0 ; 
			$action = "admin/api/2021-04/collections/{$value}/products.json?limit=250";
			$fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
			$ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
			return $response;
		}

		//Get product data by id
		public function get_product_data( $params = array() ) {

            $shopify_product_id =  !empty( $params['shopify_product_id'] ) ? $params['shopify_product_id'] : 0 ; 
			$action   = "admin/products/{$shopify_product_id}.json";
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
			return $response;
		}

        //Verify the access token and shop address/url
        public function ced_scw_fetch_collections_to_verify( $params = array() ) {

            $since_id =  !empty( $params['since_id'] ) ? $params['since_id'] : 0 ; 
            $action   = "admin/api/2022-01/custom_collections.json?limit=250&since_id={$since_id}";
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;

        }

       //Get custom collections from store by since id
        public function getCollectionsFromStore( $params ) {
            $since_id       =  !empty( $params['since_id'] ) ? $params['since_id'] : 0 ; 
            $action   = "admin/api/2022-01/custom_collections.json?limit=250&since_id={$since_id}";
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            // echo '<pre>';
            // print_r($response);
            // die('dfgf');
            return $response;
        }

        //Get smart collections from store by since id
        public function getSmartCollectionsFromStore( $params ) {

            $since_id       =  !empty( $params['since_id'] ) ? $params['since_id'] : 0 ;            
            $action = "admin/api/2022-01/smart_collections.json?limit=250&since_id={$since_id}";
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;
        }

        /* ****************************** CUSTOMER ******************************* */

        public function getCustomerFromStore( $params = array() ) {
            
            $since_id       =  !empty( $params['since_id'] ) ? $params['since_id'] : 0 ;
            $customersLimit =  !empty( $params['customers_limit'] ) ? $params['customers_limit'] : 50 ; 
			
            $action = "admin/api/2021-04/customers.json?since_id={$since_id}&limit={$customersLimit}";
			$fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;
		}

        public function getTotalCustomerFromStore( $params = array() ) {
			$action = "admin/api/2021-04/customers/count.json";
			$fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;
		}

        /* ****************************** ORDERS ******************************* */

        public function getOrdersFromStore( $params = array() ) {

            $since_id       =  !empty( $params['since_id'] ) ? $params['since_id'] : 0 ;
            $ordersLimit    =  !empty( $params['orders_limit'] ) ? $params['orders_limit'] : 50 ; 

			$action = "admin/api/2021-04/orders.json?status=any&since_id={$since_id}&limit={$ordersLimit}";

			$fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;
		}

		public function getTotalOrdersFromStore( $params = array() ) {
			$action = "admin/api/2022-07/orders/count.json?status=any";
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;
		}





		

        /**
		 * Ced_update_server_subscription_data
		 *
		 * @param  mixed $params params.
		 * @return mixed
		 */
		public function ced_update_server_subscription_data( $params = array() ) {
			$domain_name        = ! empty( $_POST['domain_name'] ) ? $_POST['domain_name'] : '';
			$marketplace_userid = ! empty( $_POST['username'] ) ? $_POST['username'] : '';
			$call_type          = ! empty( $_POST['call_type'] ) ? $_POST['call_type'] : '';
			$channel            = ! empty( $_POST['channel'] ) ? $_POST['channel'] : '';
			$servername = 'localhost';
			$username   = 'phpmyadmin';
			$password   = 'cedcom2020$';
			$dbname     = 'chargbee-api';
			$conn               = new mysqli( $servername, $username, $password, $dbname );
			if ( $conn->connect_error ) {
				echo json_encode(
					array(
						'code'    => '400',
						'message' => 'Server Connection Error. Please Contact Cedcommerce for more Information',
					)
				);
			} else {
				$sql  = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain_name' AND `userid` = '$marketplace_userid' AND `channel`='$channel' AND `status`='active'";
				$data = $conn->query( $sql );
				if ( $data->num_rows > 0 ) {
					$active_data = $data->fetch_assoc();
					if ( ! empty( $active_data ) ) {
						if ( ! empty( $call_type ) ) {
							$subscription_data = unserialize( $active_data['subscription'] );
							$remain            = isset( $subscription_data[ $call_type ]['remain'] ) ? $subscription_data[ $call_type ]['remain'] : 0;
							--$remain;
							$subscription_data[ $call_type ]['remain'] = $remain;
							$subscription_data                         = serialize( $subscription_data );
							$sql                                       = "UPDATE ced_pricing_plan SET subscription ='$subscription_data' WHERE id = " . $active_data['id'];
							if ( $conn->query( $sql ) === true ) {
								echo json_encode( array( 'code' => '200' ) );
							} else {
								echo json_encode( array( 'code' => '400' ) );
							}
						} else {
							$sql = "UPDATE ced_pricing_plan SET `status` ='restricted' WHERE id = " . $active_data['id'];
							if ( $conn->query( $sql ) === true ) {
								echo json_encode( array( 'code' => '400' ) );
							}
						}
					}
				}
			}
		}

	}
}





