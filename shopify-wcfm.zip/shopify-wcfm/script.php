<?php
    // error_reporting(~0);
    // ini_set('display_errors', 1);
    // ini_set( 'max_execution_time' , -1 );

    session_start();
    
    // require_once ('../../wp-blog-header.php');
    // if ( ! defined( 'ABSPATH' ) ) {
    //     die;
    // }

    /**
     * CED
     *
     * @class    Class_Ced_Shopify_WCFM_App
     * @version  1.0.0
     * @category Class
     * @author   CedCommerce
     */

    class Class_Ced_Shopify_WCFM_App {

        public function __construct() {

            $wooStoreURL        = isset( $_REQUEST['wooStoreURL'] ) ? ( $_REQUEST['wooStoreURL'] ) : '';
            $shopifyStoreUrl    = isset( $_REQUEST['shopifyStoreUrl'] ) ? ( $_REQUEST['shopifyStoreUrl'] ) : $_REQUEST['shop'];
            $shopifyStoreUrl	= rtrim( $shopifyStoreUrl, '/' );

            $_SESSION[$shopifyStoreUrl] = $wooStoreURL;

            $appkey = "ad6706adb5d7ade7702aff55c5f4c123";
            $secret = "8f67e80a832eaee49bf31dfddf4853ac";

            if( isset( $_REQUEST['shop'] )  && isset( $_REQUEST['code'] ) ) {                
                $ced_access_token_response = $this->ced_shopify_app_generate_access_token($_REQUEST['code'], $_REQUEST['shop'], $appkey, $secret);

                if( ! empty($ced_access_token_response) ) {
                    $scope          = isset( $ced_access_token_response['scope'] ) ? $ced_access_token_response['scope'] : "";
                    $access_token   = isset( $ced_access_token_response['access_token'] ) ? $ced_access_token_response['access_token'] : "";
                    $wooStoreURL    = ! empty($_SESSION[$_REQUEST['shop']]) ? $_SESSION[$_REQUEST['shop']] : ('https://wordpress-957220-4062555.cloudwaysapps.com/store-manager/ced-shopify');
                    
                    session_destroy();

                    header("Location: $wooStoreURL".'?access_token='.$access_token.'&shopifyStoreUrl='.$_REQUEST['shop'].'&scope='.$scope);
    
                    exit();
                }
            } else {
                $scopes         = "read_products,write_products,write_inventory,read_locations,read_orders,write_orders,write_shipping,read_fulfillments,write_fulfillments";
                $redirect_uri   = parse_url("https://woodemo.cedcommerce.com/shopify-wcfm/script.php");
                $redirect_uri   = $redirect_uri['scheme'] . "://" . $redirect_uri['host'] . $redirect_uri['path'];
                $redirect_uri   = rtrim($redirect_uri, "/");

                header("Location: https://" . $shopifyStoreUrl . "/admin/oauth/authorize?client_id=" . $appkey . "&scope=" . $scopes . "&redirect_uri=" . urlencode($redirect_uri));
                exit();
            }
        }
        
        
        public function ced_shopify_app_generate_access_token($code = "", $shopifyStoreUrl = "", $appkey = "", $secret = "") {

            $url = "https://".$shopifyStoreUrl."/admin/oauth/access_token";
    
            $connection = curl_init();
            curl_setopt($connection, CURLOPT_URL, $url);
            curl_setopt($connection, CURLOPT_SSL_VERIFYPEER, 0);
            curl_setopt($connection, CURLOPT_SSL_VERIFYHOST, 0);
            curl_setopt($connection, CURLOPT_POST, 1);
    
            $parameters = array( "client_id" => $appkey, "client_secret" => $secret, "code" => $code );
    
            curl_setopt($connection, CURLOPT_POSTFIELDS, $parameters);
            curl_setopt($connection, CURLOPT_RETURNTRANSFER, 1);
            $response = curl_exec($connection);
            curl_close($connection);
            $response = json_decode($response, true);
            return $response;
        }

    }

    $shopify_app_obj =	new Class_Ced_Shopify_WCFM_App();
?>