(function( $ ) {
	'use strict';
    
    //Dashboard	
    $('#toggle-ced-left-menu').click(function() {
        if ($('#ced-left-menu').hasClass('small-ced-left-menu')) {
            $('#ced-left-menu').removeClass('small-ced-left-menu');
        } else {
            $('#ced-left-menu').addClass('small-ced-left-menu');
        }
        $('#logo').toggleClass('small-ced-left-menu');
        $('#ced-page-container').toggleClass('small-ced-left-menu');
        $('#ced-header .ced-header-left').toggleClass('small-ced-left-menu');
    
        $('#logo .ced-main-logo').toggle('300');
        $('#logo .ced-icon-logo').toggle('300');
        $('#logo').toggleClass('p-0 pl-1');
    });


    load_data(1);

    function load_data(page, query = ''){
      $.ajax({
        url:"fetch.php",
        method:"POST",
        data:{page:page, query:query},
        success:function(data)
        {
          $('#dynamic_content').html(data);
        }
      });
    }

    $(document).on('click', '.page-link', function(){
      var page = $(this).data('page_number');
      var query = $('#search_box').val();
      load_data(page, query);
    });

    $('#search_box').keyup(function(){
      var query = $('#search_box').val();
      load_data(1, query);
    });

})( jQuery );    