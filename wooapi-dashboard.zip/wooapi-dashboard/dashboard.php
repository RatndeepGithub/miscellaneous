<?php
require_once 'partials/left-sidebar.php';
?>
<div id="ced-main-content">
    <?php
    require_once 'partials/top.php';
    ?>
    <div id="ced-page-container">
        <div class="card">
            <div class="title">Dashboard</div>
            <div class="content">
                <div class="container-fluid">
                    <div class="row">
                        <div class="col-md-12">
                            Statistics
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php
require_once 'partials/footer.php';
?>