<?php
$connect = new PDO( 'mysql:host=localhost; dbname=wooapi', 'phpmyadmin', '09ylMqe14b2' );
$limit   = '20';
$page    = 1;
if ( $_POST['page'] > 1 ) {
	$start = ( ( $_POST['page'] - 1 ) * $limit );
	$page  = $_POST['page'];
} else {
	$start = 0;
}

$query = 'SELECT * FROM ced_pricing_plan ';

if ( $_POST['query'] != '' ) {
	$query .= '
  WHERE domain LIKE "%' . str_replace( ' ', '%', $_POST['query'] ) . '%" OR subscription_id LIKE "%' . str_replace( ' ', '%', $_POST['query'] ) . '%" OR channel LIKE "%' . str_replace( ' ', '%', $_POST['query'] ) . '%" OR status LIKE "%' . str_replace( ' ', '%', $_POST['query'] ) . '%" 
  ';
}

$query .= 'ORDER BY id DESC ';

$filter_query = $query . 'LIMIT ' . $start . ', ' . $limit . '';

$statement = $connect->prepare( $query );
$statement->execute();
$total_data = $statement->rowCount();

$statement = $connect->prepare( $filter_query );
$statement->execute();
$result            = $statement->fetchAll();
$total_filter_data = $statement->rowCount();

$output = '
<label>Total Records - ' . $total_data . '</label>
<table class="table table-striped table-bordered">
  <tr>
    <th>ID</th>
    <th>Domain</th>
    <th>Subscription ID</th>
    <th>Channel</th>
    <th>Next Payment Date</th>
    <th>End Payment Date</th>
    <th>Amount</th>
    <th>Customers</th>
    <th>Orders</th>
    <th>Products</th>
    <th>Status</th>
  </tr>
';
if ( $total_data > 0 ) {
	$i = 1;
	foreach ( $result as $row ) {
		$imported_customers = ( strlen( $row['imported_customer'] ) != 0 ) ? $row['imported_customer'] : '0';
		$imported_orders    = ( strlen( $row['imported_orders'] ) != 0 ) ? $row['imported_orders'] : '0';
		$imported_products  = ( strlen( $row['imported_products'] ) != 0 ) ? $row['imported_products'] : '0';

		$subs_data = isset( $row['data'] ) ? json_decode( $row['data'], true ) : array();
		if ( is_array( $subs_data ) && ! empty( $subs_data ) ) {
			$next_payment_date = isset( $subs_data['next_payment_date'] ) ? $subs_data['next_payment_date'] : '';
			$end_date          = isset( $subs_data['end_date'] ) ? $subs_data['end_date'] : '';
			$amount            = isset( $subs_data['transactions'][0]['amount'] ) ? $subs_data['transactions'][0]['amount'] : '';
		}
		$output .= '
    <tr>
      <td>' . $i . '</td>
      <td>' . $row['domain'] . '</td>
      <td>' . $row['subscription_id'] . '</td>
      <td>' . $row['channel'] . '</td>
      <td>' . $next_payment_date . '</td>
      <td>' . $end_date . '</td>
      <td>' . $amount . '</td>
      <td>' . $imported_customers . '/' . $row['allowed_customer'] . '</td>
      <td>' . $imported_orders . '/' . $row['allowed_orders'] . '</td>
      <td>' . $imported_products . '/' . $row['allowed_products'] . '</td>
      <td>' . $row['status'] . '</td>
    </tr>
    ';
		$i       = $i + 1;
	}
} else {
	$output .= '
  <tr>
    <td colspan="2" align="center">No Data Found</td>
  </tr>
  ';
}

$output .= '
</table>
<br />
<div align="center">
  <ul class="pagination">
';

$total_links   = ceil( $total_data / $limit );
$previous_link = '';
$next_link     = '';
$page_link     = '';

// echo $total_links;

if ( $total_links > 4 ) {
	if ( $page < 5 ) {
		for ( $count = 1; $count <= 5; $count++ ) {
			$page_array[] = $count;
		}
		$page_array[] = '...';
		$page_array[] = $total_links;
	} else {
		$end_limit = $total_links - 5;
		if ( $page > $end_limit ) {
			$page_array[] = 1;
			$page_array[] = '...';
			for ( $count = $end_limit; $count <= $total_links; $count++ ) {
				$page_array[] = $count;
			}
		} else {
			$page_array[] = 1;
			$page_array[] = '...';
			for ( $count = $page - 1; $count <= $page + 1; $count++ ) {
				$page_array[] = $count;
			}
			$page_array[] = '...';
			$page_array[] = $total_links;
		}
	}
} else {
	for ( $count = 1; $count <= $total_links; $count++ ) {
		$page_array[] = $count;
	}
}

for ( $count = 0; $count < count( $page_array ); $count++ ) {
	if ( $page == $page_array[ $count ] ) {
		$page_link .= '
    <li class="page-item active">
      <a class="page-link" href="#">' . $page_array[ $count ] . ' <span class="sr-only">(current)</span></a>
    </li>
    ';

		$previous_id = $page_array[ $count ] - 1;
		if ( $previous_id > 0 ) {
			$previous_link = '<li class="page-item"><a class="page-link" href="javascript:void(0)" data-page_number="' . $previous_id . '">Previous</a></li>';
		} else {
			$previous_link = '
      <li class="page-item disabled">
        <a class="page-link" href="#">Previous</a>
      </li>
      ';
		}
		$next_id = $page_array[ $count ] + 1;
		if ( $next_id >= $total_links ) {
			$next_link = '
      <li class="page-item disabled">
        <a class="page-link" href="#">Next</a>
      </li>
        ';
		} else {
			$next_link = '<li class="page-item"><a class="page-link" href="javascript:void(0)" data-page_number="' . $next_id . '">Next</a></li>';
		}
	} else {
		if ( $page_array[ $count ] == '...' ) {
			$page_link .= '
      <li class="page-item disabled">
          <a class="page-link" href="#">...</a>
      </li>
      ';
		} else {
			$page_link .= '
      <li class="page-item"><a class="page-link" href="javascript:void(0)" data-page_number="' . $page_array[ $count ] . '">' . $page_array[ $count ] . '</a></li>
      ';
		}
	}
}

$output .= $previous_link . $page_link . $next_link;
$output .= '
  </ul>

</div>
';

echo $output;

