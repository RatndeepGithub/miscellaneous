<?php
require_once 'partials/left-sidebar.php';
?>
<div id="ced-main-content">
	<?php
	require_once 'partials/top.php';
	?>
	<div id="ced-page-container">
		<div class="card">
			<div class="title">WC API Subscriptions List</div>
			<div class="content">
				<div class="container-fluid">
					
						<div class="card-body">
							<div class="form-group">
								<input type="text" name="search_box" id="search_box" class="form-control" placeholder="Search by Domain, Subscription ID, Channel, Status" />
							</div>
							<div class="table-responsive" id="dynamic_content">
								
							</div>
						</div>
					
				</div>
			</div>
		</div>
	</div>
</div>
<?php
require_once 'partials/footer.php';
?>
