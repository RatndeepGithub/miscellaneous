<script src="assets/js/jquery-3.2.1.min.js"></script>
<script src='assets/js/bootstrap.min.js' id='bootstrap-js-js'></script>
<script src='assets/js/script.js' id='script-js'></script>
</body>
</html>