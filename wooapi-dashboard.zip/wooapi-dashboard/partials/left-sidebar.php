<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cedcommerce WC API Subscriptions Dashboard</title>
    <link rel='stylesheet' id='font-awesome-fonts-css' href='assets/fonts/fontawesome-webfont.ttf' media='all' />
    <link rel='stylesheet' id='font-awesome-fonts-woff-css' href='assets/fonts/fontawesome-webfont.woff' media='all' />
    <link rel='stylesheet' id='font-awesome-fonts-woff1-css' href='assets/fonts/fontawesome-webfont.woff2'
        media='all' />
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <link rel="stylesheet" href="assets/css/bootstrap.css">
    <link rel="stylesheet" href="assets/css/dashboard-siderbar.css">
    <link rel="stylesheet" href="assets/css/style.css">
    <meta name="robots" content="noindex">
    <meta name="googlebot" content="noindex">
</head>

<body>
    <div class="ced_loader">
        <img src="images/loading.gif" width="50px" height="50px" class="ced_loading_img">
    </div>
    <div class="loader"></div>
    <?php
        if ( isset( $_GET['tab'] ) ) {
            $tab_view = sanitize_text_field( wp_unslash( $_GET['tab'] ) );
            if ( 'dashboard' === $tab_view ) {
                require_once 'dashboard.php';
            }
        }
    ?>
    <div id="logo">
        <span class="ced-main-logo"><img src="images/cedcommerce-logo.png" /></span>
        <span class="ced-icon-logo"><img src="images/cedcommerce-icon.png" /></span>
    </div>
    <div id="ced-left-menu">
        <ul>
            <li class="<?php echo ( 'dashboard' === $tab_view ) ? 'active' : ''; ?>">
                <a href="<?php echo 'dashboard.php'; ?>">
                    <i class="fa fa-cloud-download" aria-hidden="true"></i>
                    <span><?php echo 'Dashboard'; ?></span>
                </a>
            </li>
            <li class="<?php echo ( 'subscription_list' === $tab_view ) ? 'active' : ''; ?>">
                <a href="<?php echo 'list_subscriptions.php'; ?>">
                    <i class="fa fa-cloud-download" aria-hidden="true"></i>
                    <span><?php echo 'Subscription List'; ?></span>
                </a>
            </li>
        </ul>
    </div>