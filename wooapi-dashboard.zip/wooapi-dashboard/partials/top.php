<!-- Top Bar -->
<div id="ced-header">
    <div class="ced-header-left float-left">
        <i class="fa fa-bars" id="toggle-ced-left-menu" aria-hidden="true"></i>
    </div>
    <div class="ced-header-right float-right">
        
    </div>
</div>
<!-- //Top Bar -->