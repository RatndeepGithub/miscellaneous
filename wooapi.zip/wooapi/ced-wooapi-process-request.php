<?php
$parameters = !empty( $_POST ) ? $_POST : "";
$domain = !empty( $_POST['domain'] ) ? $_POST['domain'] : "";
$channel = !empty( $_POST['channel'] ) ? $_POST['channel'] : "shopify";
$functionType = !empty( $_POST['functionType'] ) ? $_POST['functionType'] : "getCollectionsFromStore";
$is_active = check_active_subscription($domain,$channel);
if($is_active)
{
	// $parameters = array();
	// $parameters['since_id'] = 0;
	// $parameters['shop_url'] = 'shubhamdev.myshopify.com/';
	// $parameters['access_token'] = "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";
	$fileName        			= require_once 'ced-scw-ProductHelper.php';
	$ced_scw_productHelperObj 	= new Ced_Shopify_Product_Helper();
	$response_data	= $ced_scw_productHelperObj->$functionType($parameters);
	echo $response_data;
}
else
{
	echo json_encode(array('status'=> 400,'message' => 'Sorry You are not allowed to use the API requests. Please contact CedCommerce for more information.'));
}
function check_active_subscription($domain="",$channel="")
{
	$servername = "localhost";
	$username = "phpmyadmin";
	$password = "09ylMqe14b2";
	$dbname = "wooapi";
	$active = false;
	// Create connection
	$conn = new mysqli($servername, $username, $password,$dbname);

	// Check connection
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}
	else
	{
		$sql = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain' AND `channel`='$channel' AND `status`='active'";
		$data = $conn->query($sql);
		if ($data->num_rows > 0) {
			$active_data = $data->fetch_assoc();
			if(!empty($active_data))
			{
				$active = true;
			}
		}
	}
	return $active;
}