<?php
$payload = file_get_contents( 'php://input' );
$file = fopen("test.txt","w");
fwrite($file,$payload);
fclose($file);
$response = $payload;
if(!empty($response))
{
	$response = json_decode($response,true);
	$subscription_id = $response['id'];
	$subscription_status = $response['status'];
	$next_payment_date = $response['next_payment_date'];
	$end_date = $response['end_date'];
	$servername = "localhost";
	$username = "phpmyadmin";
	$password = "09ylMqe14b2";
	$dbname = "wooapi";

	// Create connection
	$conn = new mysqli($servername, $username, $password,$dbname);

	// Check connection
	if ($conn->connect_error) {
	  	die("Connection failed: " . $conn->connect_error);
	}
	else
	{
		$sql = "UPDATE ced_pricing_plan SET `status`='$subscription_status' WHERE `subscription_id`='$subscription_id'";
		$conn->query($sql);
		$sql_get = "SELECT * FROM ced_pricing_plan WHERE `subscription_id`='$subscription_id'";
		$data = $conn->query($sql_get);
		if($data)
		{
			while ($row = $data->fetch_assoc()){
		        $user_arr[] = $row;
		    }
		}
		if(!empty($user_arr))
		{
			$domain = $user_arr[0]['domain'];
		}
		$url = $domain."/wp-admin/admin-ajax.php?action=ced_update_plan";
		$connection = curl_init();
		$params['subscription_status'] = $subscription_status;
		$params['next_payment_date'] = $next_payment_date;
		$params['end_date'] = $end_date;
		curl_setopt( $connection, CURLOPT_URL, $url );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_POST, 1 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		curl_setopt( $connection, CURLOPT_POSTFIELDS, json_encode($params) );
		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, 1 );
		$response = curl_exec( $connection );
		curl_close( $connection );

	}


}
?>