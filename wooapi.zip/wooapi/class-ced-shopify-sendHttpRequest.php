<?php
class Ced_Shopify_Send_HTTP_Request {

	public $ced_shopify_access_token;
	public $api_store_address;

	public function __construct( $ced_scw_shopify_access_token = '', $ced_scw_shopify_store_url = '' ) {
		$this->ced_shopify_access_token = $ced_scw_shopify_access_token;
		$this->api_store_address      	= $ced_scw_shopify_store_url;
	}

	public function sendHttpRequest( $action = '' ) {
		if ( '' == $action ) {
			return false;
		}

		// // initialise a CURL session
		// $connection = curl_init();
		// $url        = 'https://' . $this->api_store_address . $action;
		// $headers    = $this->build_headers( $this->ced_shopify_access_token );

		// curl_setopt( $connection, CURLOPT_URL, $url );
		// curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		// curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );
		// curl_setopt( $connection, CURLOPT_RETURNTRANSFER, 1 );

		// $response = curl_exec( $connection );
		// curl_close( $connection );
		// return ( $response );

		$curl 		= curl_init();
		$url		= 'https://' . $this->api_store_address . $action;
		$headers	= $this->build_headers( $this->ced_shopify_access_token );

		curl_setopt_array($curl, array(
			CURLOPT_URL => $url,
			CURLOPT_RETURNTRANSFER => true,
			CURLOPT_ENCODING => '',
			CURLOPT_MAXREDIRS => 10,
			CURLOPT_TIMEOUT => 0,
			CURLOPT_FOLLOWLOCATION => true,
			CURLOPT_HTTP_VERSION => CURL_HTTP_VERSION_1_1,
			CURLOPT_CUSTOMREQUEST => 'GET',
			CURLOPT_HTTPHEADER => $headers
		));

		$response = curl_exec($curl);
		curl_close($curl);
		return ( $response );
	}

	public function PostHttpRequest( $action = '', $encode_product_data = array() ) {

		if ( '' == $action ) {
			return false;
		}

		// initialise a CURL session
		$connection = curl_init();
		$url        = 'https://' . $this->api_store_address . $action;
		$headers    = $this->build_headers( $this->ced_shopify_access_token );

		curl_setopt( $connection, CURLOPT_URL, $url );
		curl_setopt( $connection, CURLOPT_POST, 1 );
		curl_setopt( $connection, CURLOPT_POSTFIELDS, $encode_product_data );
		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, true );
		curl_setopt( $connection, CURLOPT_FOLLOWLOCATION, 1 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );
		$response = curl_exec( $connection );
		curl_close( $connection );
		return ( $response );
	}

	public function build_headers( $ced_shopify_access_token ) {

		$headers = array(
			'Content-type: application/json',
			'X-Shopify-Access-Token: ' . $ced_shopify_access_token . '',
		);
		return $headers;
	}

	public function parse_response( $response ) {

		$res = json_decode( $response, true );

		return $res;
	}

}
