<?php

	$plan_type = !empty( $_GET['plan_type'] ) ? $_GET['plan_type']."-staging" : "";
	$plan_period = !empty( $_GET['plan_period'] ) ? $_GET['plan_period'] : "monthly";
	$plan_cost = !empty( $_GET['plan_cost'] ) ? $_GET['plan_cost'] : "";
	$contract_id = !empty( $_GET['contract_id'] ) ? $_GET['contract_id'] : "";
	$is_cancel = !empty( $_GET['is_cancel'] ) ? $_GET['is_cancel'] : "";
	$channel = !empty( $_GET['channel'] ) ? $_GET['channel'] : "";
	$redirect_url = !empty( $_GET['redirect_url'] ) ? $_GET['redirect_url'] : "";
	if($plan_period == 'yearly')
	{
		$req_plan = 'year';
	}
	else
	{
		$req_plan = 'month';
	}
	if( $plan_period == 'onetime' )
	{
		$plan_url = 'https://sandbox.woocommerce.com/wp-json/wccom/billing/1.0/charges/';
	}
	else
	{
		$plan_url = 'https://sandbox.woocommerce.com/wp-json/wccom/billing/1.0/subscriptions/';
	}
	if(!empty($is_cancel) && $is_cancel == 'yes')
	{
		if(!empty($contract_id))
		{
			$url        = $plan_url.$contract_id;
			$headers[]  = 'Authorization: Basic MjdmOTAzOTktMmY1MS00MDY3LWE2NDEtNDQxMjRmMWFmZGJhOkN4eUIhRkJwNE1TZ1M5Xip3YWNVQk9jNUQxQENaYUFSJUNZRnZlNWVCXmIlJjV1Y092KCNLWUhHVHZEdDJ3QzlqWHJaTzJUZWZeeEApaHVrSlFxeSl4eTZDR0hMbXlIIUExYVdLcGVvRjlaaHUlS2dxQ281RUgkaEE0TkEpZDJO';
			// $headers[]  = "Content-Type: application/json";
			$connection = curl_init();
			curl_setopt( $connection, CURLOPT_URL, $url );
			curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
			curl_setopt( $connection, CURLOPT_CUSTOMREQUEST, 'DELETE' );
			curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
			curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );
			curl_setopt( $connection, CURLOPT_RETURNTRANSFER, 1 );
			$response = curl_exec( $connection );
			$error = curl_error( $connection );
			curl_close( $connection );
			$response = json_decode($response,true);
			if(empty($response))
			{
				$data = json_encode(array('status'=> '200','message' => "Subscription Cancelled Successfully."));
				echo $data;
				die;
			}
			elseif(!empty($response['message']))
			{
				$data = json_encode(array('status'=> '400','message' => $response['message']));
				echo $data;
				die;
			}
		}
		else
		{
			$data = json_encode(array('status'=> '400','message' => "some error occured.No contract id found"));
			echo $data;
			die;
		}

	}
	else
	{
		$redirect_url = "https://woodemo.cedcommerce.com/wooapi/sandbox/ced_woo_api_redirect.php?redirect=".$redirect_url.'&channel='.$channel.'&plan_name='.$plan_type.'&billing_period='.$plan_period;
		$params = array();
		$params['name'] = $plan_type;
		$params['price'] = $plan_cost;
		$params['billing_period'] = $req_plan;
		$params['billing_interval'] = 1;
		$params['return_url'] = $redirect_url;
		$params['trial_period'] = 'day';
		$params['trial_length'] = 7;
		$connection = curl_init();
		if(!empty($contract_id))
		{
			$url        = $plan_url.$contract_id;
		}
		else
		{
			$url        = $plan_url;
		}
		$headers[]  = 'Authorization: Basic MjdmOTAzOTktMmY1MS00MDY3LWE2NDEtNDQxMjRmMWFmZGJhOkN4eUIhRkJwNE1TZ1M5Xip3YWNVQk9jNUQxQENaYUFSJUNZRnZlNWVCXmIlJjV1Y092KCNLWUhHVHZEdDJ3QzlqWHJaTzJUZWZeeEApaHVrSlFxeSl4eTZDR0hMbXlIIUExYVdLcGVvRjlaaHUlS2dxQ281RUgkaEE0TkEpZDJO';
		$headers[]  = "Content-Type: application/json";
		curl_setopt( $connection, CURLOPT_URL, $url );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
		curl_setopt( $connection, CURLOPT_POST, 1 );
		curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
		curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );
		curl_setopt( $connection, CURLOPT_POSTFIELDS, json_encode($params) );
		curl_setopt( $connection, CURLOPT_RETURNTRANSFER, 1 );
		$response = curl_exec( $connection );
		curl_close( $connection );
		if(!is_array($response))
		{
			$response = json_decode($response,true);
		}
		if(!empty($response) && !empty($response['confirmation_url']))
		{
			$data = json_encode(array('status'=> '200','confirmation_url' => $response['confirmation_url']));
		}
		else
		{
			$data = json_encode(array('status'=> '400','message' => "some error occured." , 'response'=>$response));
		}
		echo $data;
		die;
	}

?>
