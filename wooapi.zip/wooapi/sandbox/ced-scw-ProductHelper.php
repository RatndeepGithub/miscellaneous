<?php
if ( ! class_exists( 'Ced_Shopify_Product_Helper' ) ) {
	class Ced_Shopify_Product_Helper {
      /* ****************************** PRODUCT ******************************* */

		//get collection products data according to collection id
		public function get_all_collection_products( $params = array() ) {
            $value          =  !empty( $params['value'] ) ? $params['value'] : 0 ; 
            $product_limit  =  !empty( $params['product_limit'] ) ? $params['product_limit'] : 0 ; 
            $pageno         =  !empty( $params['pageno'] ) ? $params['pageno'] : 0 ; 
            $domain         =  !empty( $params['domain'] ) ? $params['domain'] : "" ;
			$action = "admin/api/2021-04/collections/{$value}/products.json?limit={$product_limit}&since_id={$pageno}";
			$fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
			$ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
			return $response;
		}

		//count products in selected collection ids
		public function get_count_of_collectionproducts_on_shopify( $params = array() ) {
            $value =  !empty( $params['value'] ) ? $params['value'] : 0 ; 
			$action = "admin/api/2021-04/collections/{$value}/products.json?limit=250";
			$fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
			$ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
			return $response;
		}

		//Get product data by id
        public function get_product_data( $params = array() ) {
            $shopify_product_id =  !empty( $params['shopify_product_id'] ) ? $params['shopify_product_id'] : 0 ; 
            $action   = "admin/products/{$shopify_product_id}.json";
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;
        }

        //Verify the access token and shop address/url
        public function ced_scw_fetch_collections_to_verify( $params = array() ) {

            $since_id =  !empty( $params['since_id'] ) ? $params['since_id'] : 0 ; 
            $action   = "admin/api/2022-01/custom_collections.json?limit=250&since_id={$since_id}";
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;

        }

       //Get custom collections from store by since id
        public function getCollectionsFromStore( $params ) {
            $since_id       =  !empty( $params['since_id'] ) ? $params['since_id'] : 0 ; 
            $action   = "admin/api/2022-01/custom_collections.json?limit=250&since_id={$since_id}";
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;
        }

        //Get smart collections from store by since id
        public function getSmartCollectionsFromStore( $params ) {

            $since_id       =  !empty( $params['since_id'] ) ? $params['since_id'] : 0 ;            
            $action = "admin/api/2022-01/smart_collections.json?limit=250&since_id={$since_id}";
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;
        }

        /* ****************************** CUSTOMER ******************************* */

        public function getCustomerFromStore( $params = array() ) {
            
            $since_id       =  !empty( $params['since_id'] ) ? $params['since_id'] : 0 ;
            $customersLimit =  !empty( $params['customers_limit'] ) ? $params['customers_limit'] : 50 ; 
			$domain         =  !empty( $params['domain'] ) ? $params['domain'] : "" ;
            $action = "admin/api/2021-04/customers.json?since_id={$since_id}&limit={$customersLimit}";
			$fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            $this->updateTableData('imported_customer',$customersLimit,$domain);
            return $response;
		}

        public function getTotalCustomerFromStore( $params = array() ) {
			$action = "admin/api/2021-04/customers/count.json";
			$fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;
		}

        /* ****************************** ORDERS ******************************* */

        public function getOrdersFromStore( $params = array() ) {
            $since_id       =  !empty( $params['since_id'] ) ? $params['since_id'] : 0 ;
            $ordersLimit    =  !empty( $params['orders_limit'] ) ? $params['orders_limit'] : 50 ; 
            $domain         =  !empty( $params['domain'] ) ? $params['domain'] : "" ;
			$action = "admin/api/2021-04/orders.json?status=any&since_id={$since_id}&limit={$ordersLimit}";

			$fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            $this->updateTableData('imported_orders',$ordersLimit,$domain);
            return $response;
		}

		public function getTotalOrdersFromStore( $params = array() ) {
			$action = "admin/api/2022-07/orders/count.json?status=any";
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;
		}


        
        public function createOrderOnShopify( $params = array() ) {
            $action = 'admin/api/2023-01/orders.json';
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->PostHttpRequest( $action, $params['encodedData'] );
            return $response;
        }

        /* ****************************** LOCATIONS ******************************* */

        public function getLocationFromStore( $params = array() ) {
            $action = 'admin/api/2023-01/locations.json';
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;
        }

        /* ****************************** InventoryLevel ******************************* */

        public function updateProductStockOnShopify( $params = array() ) {
            $action = 'admin/api/2023-01/inventory_levels/adjust.json';
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->PostHttpRequest( $action, $params['encodedData'] );
            return $response;
        }

        /* ****************************** Retrieve a single product  ******************************* */

        public function getProductDataFromShopify( $params = array() ) {
            $action = "admin/api/2023-01/products/{$params['encodedData']}.json";
            $fileName = 'class-ced-shopify-sendHttpRequest.php';
            require_once $fileName;
            $ced_swc_sendHttpRequestInstance = new Ced_Shopify_Send_HTTP_Request( $params['access_token'], $params['shop_url'] );
            $response = $ced_swc_sendHttpRequestInstance->sendHttpRequest( $action );
            return $response;
        }

        public function updateTableData($column_name = "", $column_value = "", $domain ="") {
            $servername = "localhost";
            $username = "phpmyadmin";
            $password = "09ylMqe14b2";
            $dbname = "wooapi";
            $active = false;
            // Create connection
            $conn = new mysqli($servername, $username, $password,$dbname);
            $data_val = "";
            $sql_get = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain'";
            $data = $conn->query($sql_get);
            if($data)
            {
                while ($row = $data->fetch_assoc()){
                    $user_arr[] = $row;
                }
            }
            if(!empty($user_arr))
            {
                foreach ($user_arr[0] as $key => $value) {
                    if($key === $column_name)
                    {
                        $data_val = $value;
                    }
                }
                
            }
            $updated_val = (int)$data_val + $column_value;
            $sql = "UPDATE ced_pricing_plan SET `$column_name` ='$updated_val' WHERE `domain`='$domain'";
            // var_dump($sql);die("test");
            $conn->query($sql);
        
        }
	}
}





