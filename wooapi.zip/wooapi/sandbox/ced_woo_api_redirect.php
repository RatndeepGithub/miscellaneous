<img src="Walk.gif">
<?php
	// $domain = "localhost/new_setup";
	// $channel = "shopify";
	// $data = "shopifysdadasdasdas";
	// $servername = "localhost";
	// $username = "phpmyadmin";
	// $password = "09ylMqe14b2";
	// $dbname = "wooapi";

	// // Create connection
	// $conn = new mysqli($servername, $username, $password,$dbname);

	// // Check connection
	// if ($conn->connect_error) {
	//   die("Connection failed: " . $conn->connect_error);
	// }
	// else
	// {
	// 	$sql = "INSERT INTO ced_pricing_plan (domain, channel,data,allowed_customer,allowed_orders,allowed_products)
	// VALUES ('$domain', '$channel','$response','1000','1000','1000')";
	// 	$conn->query($sql);
	// 	print_r($sql);
	// 	print_r($conn);
	// 	$redirect_url = $domain.'/wp-admin/admin.php?page=ced_shopify&success=yes&contract_id='.$_GET['contract_id'];
	// 	// header("Location: ".$redirect_url);
	// }
	// die("sdfdsdfsd");
if(!empty($_GET['contract_id']))
{
	$domain = !empty( $_GET['redirect'] ) ? $_GET['redirect'] : "";
	$channel = !empty( $_GET['channel'] ) ? $_GET['channel'] : "";
	$plan_name = !empty( $_GET['plan_name'] ) ? $_GET['plan_name'] : "";
	$billing_period = !empty( $_GET['billing_period'] ) ? $_GET['billing_period'] : "";
	$connection = curl_init();
	$url = 'https://sandbox.woocommerce.com/wp-json/wccom/billing/1.0/subscriptions/'.$_GET['contract_id'];
	$headers[]  = 'Authorization: Basic MjdmOTAzOTktMmY1MS00MDY3LWE2NDEtNDQxMjRmMWFmZGJhOkN4eUIhRkJwNE1TZ1M5Xip3YWNVQk9jNUQxQENaYUFSJUNZRnZlNWVCXmIlJjV1Y092KCNLWUhHVHZEdDJ3QzlqWHJaTzJUZWZeeEApaHVrSlFxeSl4eTZDR0hMbXlIIUExYVdLcGVvRjlaaHUlS2dxQ281RUgkaEE0TkEpZDJO' ;
	curl_setopt( $connection, CURLOPT_URL, $url );
	curl_setopt( $connection, CURLOPT_SSL_VERIFYPEER, 0 );
	curl_setopt( $connection, CURLOPT_SSL_VERIFYHOST, 0 );
	curl_setopt( $connection, CURLOPT_HTTPHEADER, $headers );
	curl_setopt( $connection, CURLOPT_RETURNTRANSFER, 1 );
	$response = curl_exec( $connection );
	$response_data = json_decode($response,true);
	$subscriptionId = $response_data['id'];
	$subs_status = $response_data['status'];
	$next_payment_date = $response_data['next_payment_date'];
	$end_date = $response_data['end_date'];
	curl_close( $connection );

	$plan_data = file_get_contents("https://woodemo.cedcommerce.com/wooapi/sandboxced_pricing_plan_options.json");
	$prod_plandata = array();
	if(!empty($plan_data))
	{
	  $plan_data = json_decode($plan_data,true);
	  if(!empty($channel) && !empty($billing_period) && !empty($plan_name))
	  {
	    $prod_plandata = $plan_data[$channel][$billing_period][$plan_name]; 
	  }
	}
	$allowed_products  = 1000;
	$allowed_customers = 1000;
	$allowed_orders    = 1000;
	if(!empty($prod_plandata))
	{
		$allowed_products  = $prod_plandata['allowed_products'];
		$allowed_customers = $prod_plandata['allowed_customers'];
		$allowed_orders    = $prod_plandata['allowed_orders'];
	}
	$servername = "localhost";
	$username = "phpmyadmin";
	$password = "09ylMqe14b2";
	$dbname = "wooapi";

	// Create connection
	$conn = new mysqli($servername, $username, $password,$dbname);

	// Check connection
	if ($conn->connect_error) {
	  die("Connection failed: " . $conn->connect_error);
	}
	else
	{
		$sql = "SELECT * FROM ced_pricing_plan WHERE `domain`='$domain' AND `channel`='$channel'";
		$data = $conn->query($sql);
		if ($data->num_rows > 0) {
			$sql = "UPDATE ced_pricing_plan SET `subscription_id`= '$subscriptionId',`data`='$response', `allowed_customer` = '$allowed_customers', `allowed_orders`= '$allowed_orders',`allowed_products`= '$allowed_products', `status`= '$subs_status' WHERE `domain`='$domain' AND `channel`='$channel'";
			$conn->query($sql);
		}
		else
		{
			$sql = "INSERT INTO ced_pricing_plan (domain, subscription_id,channel,data,allowed_customer,allowed_orders,allowed_products,status)
	VALUES ('$domain','$subscriptionId', '$channel','$response','$allowed_customers','$allowed_orders','$allowed_products','$subs_status')";
			$conn->query($sql);

		}
		$redirect_url = $domain.'/wp-admin/admin.php?page=ced_shopify&success=yes&contract_id='.$_GET['contract_id'].'&plan_name='.$plan_name.'&billing_period='.$billing_period.'&status='.$subs_status.'&next_payment_date='.$next_payment_date.'&end_date='.$end_date;
		header("Location: ".$redirect_url);
	}
}


?>